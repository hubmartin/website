#ifndef __main_h_included__
#define __main_h_included__

volatile int delay_ding = 20;
volatile int delay_wait = 500;
volatile int dings = 0;


void delay_ms(uint16_t x);   

#endif /* __main_h_included__ */
