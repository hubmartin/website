#ifndef __rf_h_included__
#define __rf_h_included__

#include <avr/io.h>
#include <avr/wdt.h>
#include <avr/interrupt.h>  /* for sei() */
#include <util/delay.h>     /* for _delay_ms() */

#define RF_1_LOW 120
#define RF_1_HIGH 58
#define RF_0_LOW 58
#define RF_0_HIGH 120
#define RF_START 58

#define RF_PORT PORTB
#define RF_SETMASK 0x01
#define RF_CLRMASK 0xfe


volatile unsigned char rf_pos;
volatile unsigned char rf_busy;


void rf_send (uint16_t network, unsigned char payload);
void rf_init (void);



#endif /* __main_h_included__ */
