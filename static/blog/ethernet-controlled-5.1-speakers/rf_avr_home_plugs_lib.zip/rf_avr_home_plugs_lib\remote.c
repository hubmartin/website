/* Name: main.c
 * Project: PowerSwitch based on AVR USB driver
 * Author: Christian Starkjohann
 * Creation Date: 2005-01-16
 * Tabsize: 4
 * Copyright: (c) 2005 by OBJECTIVE DEVELOPMENT Software GmbH
 * License: GNU GPL v2 (see License.txt) or proprietary (CommercialLicense.txt)
 * This Revision: $Id: main.c 452 2007-12-14 20:11:57Z cs $
 */

#include <avr/io.h>
#include <avr/wdt.h>
#include <avr/interrupt.h>  /* for sei() */
#include <util/delay.h>     /* for _delay_ms() */

//#include "requests.h"       /* The custom request numbers we use */
#include "main.h"
#include "rf.h"             // Delay times for RF transmissions

#include "delay.h"

unsigned int i;


void LED()
{
	while(1)
	{
	    PORTC = 0;
		for(i = 0; i < 40000; i++);
		PORTC = 255;
		for(i = 0; i < 40000; i++);
	}
}








int __attribute__((noreturn)) main(void)
{
	unsigned int i = 0;

    rf_init();
    

	//wdt_enable(WDTO_1S);
	wdt_disable();
	/* Even if you don't use the watchdog, turn it off here. On newer devices,
	* the status of the watchdog (on/off, period) is PRESERVED OVER RESET!
	*/
	/* RESET status: all port bits are inputs without pull-up.
	* That's the way we need D+ and D-. Therefore we don't need any
	* additional hardware initialization.
	*/

	
	sei();

	for(;;)
	{                /* main event loop */

		//wdt_reset();
        
        delay_ms(10);

        if (rf_busy == 1)
        {
            PORTC |= 0x01;
        } else
        {
            PORTC &= ~(0x01);
        }

		i++;

		if(i == 200)
		{
			rf_send(0x0000, 0b10001000);
		}

		if(i == 400)
		{
			i = 0;
			rf_send(0x0000, 0);
		}
	}
}
