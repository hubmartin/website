
//#include "main.h"
#include "rf.h"

/* ------------------------------------------------------------------------- */
/* ----------------------------- RF stuff----------------------------------- */
/* ------------------------------------------------------------------------- */


volatile unsigned char rf_next = 0;
volatile unsigned char rf_next_delay = 255;
volatile unsigned char rf_buffer[42];


volatile uint16_t rf_network_id = 0x0000;

// Timer interrupt for RF sending
ISR(TIMER2_COMP_vect)
{
    // Set the delay time determined on the last interrupt run
    OCR2 = rf_next_delay;

    // Set the ip port status
    if (rf_next == 1)
    {
        RF_PORT |= RF_SETMASK;
    } else
    {
        RF_PORT &= RF_CLRMASK;
    }

    // Check if we have more data to transmit
    if (rf_pos < 42)
    {
        // rf is busy
        rf_busy = 1;

        // Every odd period is high.
        if (rf_pos & 0x01)
        {
            rf_next = 1;
        } else
        {
            rf_next = 0;
        }
        // Set the next delay
        rf_next_delay = rf_buffer[rf_pos++];
    } else
    {
        // All data transmitted.
        // set io port low
        rf_next = 0;
        // Indicate that we can send a new frame
        rf_busy = 0;
    } 
}


// Initiate RF related stuff
void rf_init (void)
{
    DDRB = 0xff;
    PORTB &= ~(0x02); // Start with transistor off

    DDRD |= 0b11101011; // Dont touch USB ports
    DDRD &= (1 << 7); // AIN1 input

    DDRC = 0xff;
    PORTC = 0x00;

    // Initiate timer 2
    // RF send timer interrupt
    TCNT2 = 0;
    OCR2 = 120;
    TCCR2 |= (1 << CS22) | (1 << CS20); // 128 prescaler
    TCCR2 |= (1 << WGM21); // CTC mode
    TIMSK |= (1 << OCIE2); // Enable CTC interrupt

	rf_busy = 0;
    rf_pos = 42;

}


void rf_send (uint16_t network, unsigned char payload)
{
    unsigned char i=0;
    unsigned char x;

    // Send a start bit
    rf_buffer[i++] = RF_1_LOW;
    rf_buffer[i++] = RF_START;

    // Send the 12 network id bits
    for (x=0; x<12; x++)
    {
        if ((network >> (x)) & 1)
        {
            rf_buffer[i++] = RF_1_LOW;
            rf_buffer[i++] = RF_1_HIGH;
        } else
        {
            rf_buffer[i++] = RF_0_LOW;
            rf_buffer[i++] = RF_0_HIGH;
        }
    }

    // Send the payload
    for (x=0; x<8; x++)
    {
        if ((payload >> (x)) & 1)
        {
            rf_buffer[i++] = RF_1_LOW;
            rf_buffer[i++] = RF_1_HIGH;
        } else
        {
            rf_buffer[i++] = RF_0_LOW;
            rf_buffer[i++] = RF_0_HIGH;
        }
    }

    // Set the rf buffer position to 0 so the interrupt routine will start working.
    rf_pos = 0;

}

