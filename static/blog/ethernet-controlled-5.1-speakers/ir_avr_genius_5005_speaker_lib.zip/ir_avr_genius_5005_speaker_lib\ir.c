/*

IR Library for Genius 5005 speakers
by Martin Hubacek
http://www.martinhubacek.cz

*/

#include "ir.h"
#include "delay.h"


unsigned short ir_header = 0x03fc;
unsigned short ir_commands[] = {0xa956, 0xa15e, 0x51ae, 0x916e, 0x11ee, 0xb14e, 0x49b6, 0x09f6};


void ir_init()
{

	TCCR0A = _BV(COM0A0) | _BV(WGM01);
	TCCR0B = _BV(CS01);

	OCR0A = 0x1c;

	// OCR0A @ 16MHz
	// 19 - 38,4kHz
	// 1c - 34,47kHz

}



void ir_send(unsigned char cmd)
{

	
	unsigned short val;
	unsigned char i, j;
	

	IR_ON();
	delay_us(9115);

	IR_OFF();
	delay_us(4444);

	val = ir_header;

	for( j = 0; j < 2; j++)
	{


		for( i = 0; i < 16; i++)
		{
			IR_ON();
			delay_us(612);
			IR_OFF();

			if(val & _BV(15))
			{
				delay_us(1610);
			} else 
			{
				delay_us(498);
			}


			val <<= 1;

		}
		val = ir_commands[cmd];
	}

	IR_ON();
	delay_us(612);
	IR_OFF();
	delay_us(1610);


}
