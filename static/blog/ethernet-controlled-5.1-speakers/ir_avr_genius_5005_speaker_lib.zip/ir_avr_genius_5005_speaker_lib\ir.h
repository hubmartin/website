/*

IR Library for Genius 5005 speakers
by Martin Hubacek
http://www.martinhubacek.cz

*/

#ifndef _ir_h_
#define _ir_h_

#define IR_STANDBY 	0
#define IR_DVD 		1
#define IR_CD 		2
#define IR_MUTE 	3
#define IR_GAME 	4
#define IR_TV 		5
#define IR_VOL_DOWN	6
#define IR_VOL_UP 	7

#define IR_ON() DDRD=_BV(PIND6)
#define IR_OFF() DDRD&=~_BV(PIND6)

void ir_init();
void ir_send(unsigned char cmd);

#endif
