/* Name: main.c
 * Project: PowerSwitch based on AVR USB driver
 * Author: Christian Starkjohann
 * Creation Date: 2005-01-16
 * Tabsize: 4
 * Copyright: (c) 2005 by OBJECTIVE DEVELOPMENT Software GmbH
 * License: GNU GPL v2 (see License.txt) or proprietary (CommercialLicense.txt)
 * This Revision: $Id: main.c 452 2007-12-14 20:11:57Z cs $
 */

#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>


#include "delay.h"
#include "ir.h"


// pin 6 pwm
// PD6 - OC0A


void beginSerial(long baud)
{

	UBRR0H = ((F_CPU / 16 + baud / 2) / baud - 1) >> 8;
	UBRR0L = ((F_CPU / 16 + baud / 2) / baud - 1);
	

	UCSR0B |= _BV(RXEN0) | _BV(TXEN0);
	
}

void serialWrite(unsigned char c)
{

	while (!(UCSR0A & (1 << UDRE0)));
	UDR0 = c;
}

signed short serialRead()

{

	if((UCSR0A & _BV(RXC0)) == 0)
		return -1;

	return UDR0;

}






int main(void)
{

signed short c;


    
	ir_init();
	beginSerial(115200);

// start frame

	


    while(1) 
    {

		c = serialRead();
		if(c != -1)
		{
			ir_send(c);
			serialWrite(c + 'A');
		}

	

	}
    return 0;
}

