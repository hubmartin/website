

// ***********************************
//
//		Valentine Blinking Heart 2011
//		Martin Hubacek
//		www.martinhubacek.cz
//
// ***********************************


// Attiny2313 running @ 1MHz (8Mhz with divider by 8), this is default settings of chip from factory
#define F_CPU 1000000UL

#include <avr/interrupt.h>
#include <avr/io.h>
#include <util/delay.h>
#include <avr/sleep.h>

unsigned int i, j;
unsigned int temp;
unsigned char effect = 0;

ISR(INT0_vect)
{
	// nothing here, just turn chip on
}

/*
7 PD0
6 PB3
5 PB2
4 PB1
3 PB0
2 PD5
1 PD4
0 PD1
*/
void setLED(unsigned char b)
{
	unsigned char bit[8];

	bit[7] = (b & _BV(7)) ? 1 : 0;
	bit[6] = (b & _BV(6)) ? 1 : 0;
	bit[5] = (b & _BV(5)) ? 1 : 0;
	bit[4] = (b & _BV(4)) ? 1 : 0;
	bit[3] = (b & _BV(3)) ? 1 : 0;
	bit[2] = (b & _BV(2)) ? 1 : 0;
	bit[1] = (b & _BV(1)) ? 1 : 0;
	bit[0] = (b & _BV(0)) ? 1 : 0;


	PORTD = bit[7] << PIND0 | bit[2] << PIND5 | bit[1] << PIND4 | bit[0] << PIND1;
	PORTB = bit[6] << PINB3 | bit[5] << PINB2 | bit[4] << PINB1 | bit[3] << PINB0;
}

// Set data direction registers
void setDDRs()
{
	DDRD |= 1 << PIND0 | 1 << PIND5 | 1 << PIND4 | 1 << PIND1;
	DDRB |= 1 << PINB3 | 1 << PINB2 | 1 << PINB1 | 1 << PINB0;
}

// Clear DDRs, I hope that it lowers power consumption, despite the fact that
// from what I measured, it did not :)
void clearDDRs()
{
	DDRD &= ~(1 << PIND0 | 1 << PIND5 | 1 << PIND4 | 1 << PIND1);
	DDRB &= ~(1 << PINB3 | 1 << PINB2 | 1 << PINB1 | 1 << PINB0);
}


// effects here
void action()
{
	// activate outputs
	setDDRs();

	// Five effects, so modulo 5
	switch(effect % 5)
	{

		// Blink 3 times, stay while on, blink 3 times
		case 0:
			for(i = 0; i < 3; i++)
			{
				setLED(0xff);
				_delay_ms(100);
				setLED(0x00);
				_delay_ms(100);
			}

			setLED(0xff);
			for(i = 0; i < 20; i++)
				_delay_ms(100);

			for(i = 0; i < 3; i++)
			{
				setLED(0xff);
				_delay_ms(100);
				setLED(0x00);
				_delay_ms(100);
			}
			break;

		// One LED "running in circle" 15 times 
		case 1:
			
			for(j = 0; j < 15; j++)
			{
			temp = 1;
				for(i = 0; i < 8; i++)
				{
					setLED(temp);
					_delay_ms(30);
					temp <<= 1;
				}
			}
			break;

		// One LED "running in circle" 15 times another direction
		case 2:
			for(j = 0; j < 15; j++)
			{
			temp = _BV(7);
				for(i = 0; i < 8; i++)
				{
					setLED(temp);
					_delay_ms(30);
					temp >>=  1;
				}
			}
			break;

		// LED running in circle leaving the previous LED turned on
		case 3:
			temp = 0;
			for(i = 0; i < 8; i++)
			{
				temp |= _BV(i);
				setLED(temp);
				_delay_ms(100);
			}
			for(i = 0; i < 10; i++)
				_delay_ms(100);

			break;

		// LED running in circle leaving the previous LED turned on, opossite direction
		case 4:
			temp = 0;
			for(i = 0; i < 8; i++)
			{
				temp |= _BV(7-i);
				setLED(temp);
				_delay_ms(100);
			}
			for(i = 0; i < 10; i++)
				_delay_ms(100);

			break;


		default:
			// just in case... 
			setLED(0xff);
			break;
	}

// Turn all LEDs off for safe reasons to power consumption
setLED(0x00);			

}





int main()
{
	int i;

	// INT0 pin up
	PORTD |= _BV(PIND2);

	// Enable INT0, low level (not trigger)
	GIMSK = _BV(INT0);
	//MCUCR = /* _BV(ISC01) |*/ _BV(SE) | _BV(SM);

	set_sleep_mode(SLEEP_MODE_PWR_DOWN);

	while(1)
	{
		
		sei();
		sleep_mode();
		cli();
		
		action();
		effect++;

		setLED(0x00);
		clearDDRs();

		PORTD |= _BV(PIND2);
		while(bit_is_clear(PIND,PIND2));
	}

}
