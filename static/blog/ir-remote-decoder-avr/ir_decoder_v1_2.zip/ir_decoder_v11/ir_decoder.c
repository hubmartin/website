/* 

	http://www.martinhubacek.cz
	IR decoder by Martin Hubacek
	Version 1.1
	16.6.2011

 */

#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <avr/eeprom.h>

#include "ir_decoder.h"

// NEC code for LG remote and unused SimpLink button
uint16_t EEMEM eeSavedCode = 0x207E;

unsigned char repeatCount = 0;


#define UART_UBBR_VALUE ((F_CPU/(UART_BAUD<<4))-1)

void uartInit(void)
{
	// Set baud rate
	UBRRH = (unsigned char)UART_UBBR_VALUE >> 8;
	UBRRL = (unsigned char)UART_UBBR_VALUE;

	// Set frame format to 8 data bits, no parity, 1 stop bit
	UCSRC = _BV(URSEL) | _BV(USBS) | (3<<UCSZ0);

	// Enable receiver and transmitter
	UCSRB = _BV(RXEN) | _BV(TXEN);
}

void uartSend(uint8_t u8Data)
{
	while((UCSRA&(1<<UDRE)) == 0);
	UDR = u8Data;
}

void uartSendNibble(unsigned char nibble)
{
	if(nibble < 10)
		uartSend(nibble + '0');
	else
		uartSend(nibble - 10 + 'A');
}

void uartSendCode(unsigned int code)
{
	// print "0x"
	uartSend('0');
	uartSend('x');
	// print 4 HEX digits
	uartSendNibble(code >> 12);
	uartSendNibble((code >> 8) & 0x0f);
	uartSendNibble((code >> 4) & 0x0f);
	uartSendNibble(code  & 0x0f);

	// CR
	uartSend(13);
	// LF
	uartSend(10);

}



void blink()
{
	// Debug LED on
	PORTC |= _BV(PINC3);

	// Wait 20ms
	TIMER_REG = 0;
	while(TIMER_REG < CONV(20000));

	// Debug LED off
	PORTC &= ~_BV(PINC3);

}

// The input IR code is matching
// the learned code
void codeMatch(unsigned int code)
{

	
	// pull-down the pin connected to the
	// computer's power on button
	START_DDR |= _BV(START_PIN);

	blink();

	// Hi-Z again
	START_DDR &= ~(_BV(START_PIN));


}


void init()
{
	// Initialize timer's prescaler
	TIMER_INIT();

	// Enable pull-up on IR pin
	if(IR_ENABLE_PULLUP)
		IR_PORT |= _BV(IR_PIN_NUM);

	// Jumper pull-up
	PORTB |= _BV(PINB0);

	// Debug LED output - all pins on PORTC
	DDRC = 255;

	uartInit();
}


unsigned int protocolSIRC(unsigned int code)
{
	unsigned int time;
	unsigned char i;

	static unsigned int lastCode = 0;

		code = 0;	

		// Read 32 data bits
		for(i = 0; i < 12; i++)
		{
			
			while(IR_LOW)
				if(TIMER_REG > CONV(2000))
					return 0;
			while(IR_HIGH)
				if(TIMER_REG > CONV(2000))
					return 0;

			time = TIMER_REG;
			TIMER_REG = 0;

			// error check - pulse length between 500-2000us
			if(time < CONV(400) || time > CONV(2000))
				return 0;

			code = code << 1;

			// 1440 us
			if(time > CONV(1440))
				code |= 1;


		}

	if(code == lastCode)
	{
		if((repeatCount++) == SIRC_REPEAT_RATE)
		{
			repeatCount = 0;
			return code;
		} else {
			return 0;
		}
	}

	lastCode = code;

	return code;
}


unsigned int protocolRC5(unsigned int code)
{

	unsigned char repeatBit;
	unsigned char i;

	static unsigned int lastCode = 0;
	static unsigned char lastRepeatBit = 0;

	unsigned char errorBit;

	code = 0;

	// 3160 us offset from the first pulse
	while(TIMER_REG < CONV(3160));
	TIMER_REG = 0;

	// Read "repeat" bit
	repeatBit = IR_VAL;
	PORTC ^= _BV(PINC5);

	// Move 1760us to the first data bit
	while(TIMER_REG < CONV(880));
	TIMER_REG = 0;

	// Read 12 data bits (5 address & 7 command)
	for(i = 0; i < 11; i++)
	{

		code = code << 1;


		PORTC ^= _BV(PINC5);
		errorBit = IR_VAL;

		//while(TIMER_REG < CONV(RC5_DELAY_0));
		//TIMER_REG = 0;

		// Read second half of bit, which has to be inverted
		// so we check whether the code is ok

		while(errorBit == IR_VAL)
			if(TIMER_REG > CONV(1000))
				return 0;

		
		TIMER_REG = 0;
		while(TIMER_REG < CONV(400));
		TIMER_REG = 0;

		PORTC ^= _BV(PINC5);
		
		if(IR_VAL)
			code |= 0x0001;

		// If the previous and current bit is the same - we have error code
		if(IR_VAL && errorBit)
			return 0;
			

		
		while(TIMER_REG < CONV(800));
		TIMER_REG = 0;


	}

	if(code == lastCode && repeatBit == lastRepeatBit)
	{
		if(++repeatCount == RC5_REPEAT_RATE)
		{
			repeatCount = 0;
			return code;
		} else {
		 return 0;
		}
	}

	if(repeatBit != lastRepeatBit)
	{
		repeatCount = 0;
	}

	lastCode = code;
	lastRepeatBit = repeatBit;
	return code;

}


unsigned int protocolNEC(unsigned int code)
{

	unsigned char bitVal;
	unsigned int time;
	unsigned char i;

	unsigned int invertedCode = 0;

	static unsigned int lastCode = 0;


		while(IR_HIGH);/*
			if(TIMER_REG > CONV(5000))
				return 0;*/

		time = TIMER_REG;
		TIMER_REG = 0;

		PORTC ^= _BV(PINC5);

		// 4200 us
		if(time > CONV(4200))
		{
			// regular button press
			repeatCount = 0;
		} else {
			
			// hold button press
			// send last keycode
			if(++repeatCount == NEC_REPEAT_RATE)
			{
				repeatCount = 0;
				return lastCode;
			}
			return 0;
		}

		
		code = 0;

		// Read 32 data bits
		for(i = 0; i < 32; i++)
		{
			
			while(IR_LOW);
			/*	if(TIMER_REG > CONV(5000))
					return 0;*/
			while(IR_HIGH);/*
				if(TIMER_REG > CONV(5000))
					return 0;*/

			time = TIMER_REG;
			TIMER_REG = 0;
			
			// 1650 us
			if(time > CONV(1650))
			{
				bitVal = 1;
			} else {
				bitVal = 0;
			}

			PORTC ^= _BV(PINC5);
			
			if((i < 8) || (i >= 16 && i < 24))
			{
				code = code << 1;
				code |= bitVal;
			}

			if((i >= 8 && i < 16) || (i >= 24 && i < 32))
			{
				invertedCode = invertedCode << 1;
				invertedCode |= bitVal;
			}
		}

		if(code != ~invertedCode)
			return 0;

		lastCode = code;
		return code;
}


int main(void)
{

	unsigned int savedCode;
	unsigned int code = 0;
	unsigned int time;

	unsigned char protocolLetter;

    
	init();

	savedCode = eeprom_read_word(&eeSavedCode);


OSCCAL = 0x70;

/*
TIMER_REG = 0;
	while(1)
	{

		while(TIMER_REG < CONV(500));
		TIMER_REG = 0;

		PORTC = _BV(PINC5);

		while(TIMER_REG < CONV(500));
		TIMER_REG = 0;

		PORTC &= ~_BV(PINC5);


	}*/

    while(1) 
    {
    	
		PORTC ^= _BV(PINC5);
		while(IR_HIGH);
		PORTC ^= _BV(PINC5);
		TIMER_REG = 0;
		while(IR_LOW);
		//PORTC ^= _BV(PINC5);
		
		time = TIMER_REG;
		
		TIMER_REG = 0;

		// Initial pulse length between 9ms and 9.8ms => NEC protocol
		if(time > CONV(9000) && time < CONV(9800)) {
			protocolLetter = 'N';
			uartSend(protocolLetter);
			code = protocolNEC(code);

		// Initial pulse length between 0.8ms and 1.2ms => RC5 protocol
		} else if(time > CONV(800) && time < CONV(1200)) {
			protocolLetter = 'R';
			uartSend(protocolLetter);
			code = protocolRC5(code);

		// Initial pulse length between 2ms and 2.8ms => SIRC protocol
		} else if(time > CONV(2000) && time < CONV(2800)) {
			protocolLetter = 'S';
			uartSend(protocolLetter);
			code = protocolSIRC(code);

		// Unkwnown initial pulse length
		} else {
			continue;
		}

		// If code is wrong, we get 0
		if(code == 0)
			continue;


		// Learning mode
		if((PINB & _BV(PINB0)) == 0)
		{
			savedCode = code;
			eeprom_write_word(&eeSavedCode, savedCode);
			blink();
			continue;
		}

		// Code match
		if(code == savedCode)
		{
			codeMatch(code);
		}



		// Send protocol letter and code over UART
		//uartSend(protocolLetter);
		uartSendCode(code);

	}
    return 0;
}

