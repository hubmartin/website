/* 

	http://www.martinhubacek.cz
	IR decoder by Martin Hubacek
	Version 1.0
	15.6.2011

 */

// Define your IR port and IR pin
#define IR_PIN PIND
#define IR_PIN_NUM PIND2
#define IR_PORT PORTD

#define IR_ENABLE_PULLUP 1


// Define pin to start computer - pull-down
#define START_PORT	PORTB
#define START_DDR	DDRB
#define START_PIN	PINB1


// Define repeat rate of long-hold buttons
// This is actually prescale value
#define NEC_REPEAT_RATE 5
#define RC5_REPEAT_RATE 5
#define SIRP_REPEAT_RATE 5


// UART Baudrate
#define USART_BAUD 115200


// only 8 for now
#define TIMER_PRESCALER 8


#if TIMER_PRESCALER == 8
	#define TIMER1_PRESCALER _BV(CS11)
#endif

// Maximal time is about 47407us = 47,407ms !
// 47407 => 65535 cycles, the timer is 16bit so maximum
// value is 65535
#define CONV(x) ((F_CPU/TIMER_PRESCALER)/(1000000/x))


#define IR_HIGH  (IR_PIN & _BV(IR_PIN_NUM))
#define IR_LOW (!(IR_PIN & _BV(IR_PIN_NUM)))
#define IR_VAL (IR_PIN & _BV(IR_PIN_NUM))
