/*************************************************************************
Title:    testing output to a HD44780 based LCD display.
Author:   Peter Fleury  <pfleury@gmx.ch>  http://jump.to/fleury
File:     $Id: test_lcd.c,v 1.6 2004/12/10 13:53:59 peter Exp $
Software: AVR-GCC 3.3
Hardware: HD44780 compatible LCD text display
          ATS90S8515/ATmega if memory-mapped LCD interface is used
          any AVR with 7 free I/O pins if 4-bit IO port mode is used
**************************************************************************/
#include <stdlib.h>
#include <avr/io.h>
#include <avr/pgmspace.h>
#include <string.h>

#include <avr/interrupt.h>
#include <avr/pgmspace.h>

#include <avr/sleep.h>


#include "delay.h"
#include "font.h"


#define F_OSC	8000000





#define PLAY_ONCE _BV(15)
#define TEXT_FLAG _BV(14)

/*

0x0000
  ||||
  ||\\== Green LEDs
  ||
  \\=== Red LEDs
  	
*/

const unsigned int buffer[] PROGMEM ={14,3 | PLAY_ONCE,
	0x01ff,0x0100,0x0100,0x0100,0x0100,0x0100,0x0100,0x0100,
	0x0200,0x02ff,0x0200,0x0200,0x0200,0x0200,0x0200,0x0200,
	0x0400,0x0400,0x04ff,0x0400,0x0400,0x0400,0x0400,0x0400,
	0x0800,0x0800,0x0800,0x08ff,0x0800,0x0800,0x0800,0x0800,
	0x1000,0x1000,0x1000,0x1000,0x10ff,0x1000,0x1000,0x1000,
	0x2000,0x2000,0x2000,0x2000,0x2000,0x20ff,0x2000,0x2000,
	0x4000,0x4000,0x4000,0x4000,0x4000,0x4000,0x40ff,0x4000,
	0x8000,0x8000,0x8000,0x8000,0x8000,0x8000,0x8000,0x80ff,

0x4000,0x4000,0x4000,0x4000,0x4000,0x4000,0x40ff,0x4000,
0x2000,0x2000,0x2000,0x2000,0x2000,0x20ff,0x2000,0x2000,
0x1000,0x1000,0x1000,0x1000,0x10ff,0x1000,0x1000,0x1000,
	0x0800,0x0800,0x0800,0x08ff,0x0800,0x0800,0x0800,0x0800,
	0x0400,0x0400,0x04ff,0x0400,0x0400,0x0400,0x0400,0x0400,
	0x0200,0x02ff,0x0200,0x0200,0x0200,0x0200,0x0200,0x0200,


						};



const unsigned int allColors[] PROGMEM ={3,30 | PLAY_ONCE,
	0x00ff,0x00ff,0x00ff,0x00ff,0x00ff,0x00ff,0x00ff,0x00ff,
	0xff00,0xff00,0xff00,0xff00,0xff00,0xff00,0xff00,0xff00,
	0xffff,0xffff,0xffff,0xffff,0xffff,0xffff,0xffff,0xffff,
	
						};


const unsigned int tengu[] PROGMEM = {8, 10 | PLAY_ONCE, 0, 0, 66, 26, 10, 66, 0, 0, 
0, 0, 66, 27, 11, 66, 0, 0, 
4, 6, 67, 27, 11, 67, 6, 4, 
1024, 1536, 1856, 1816, 1800, 1856, 1536, 1024, 
1024, 1536, 18176, 1816, 1800, 18176, 1536, 1024, 
1024, 1536, 18178, 1818, 1802, 18178, 1536, 1024, 
1024, 28160, 28418, 3858, 3842, 28418, 28160, 1024, 
1024, 28164, 28422, 3862, 3846, 28422, 28164, 1024, 
 };


 const unsigned int pong[] PROGMEM = {28, 8 | PLAY_ONCE, 57344, 16448, 0, 0, 0, 0, 0, 7, 

57344, 0, 8224, 0, 0, 0, 0, 7, 
28672, 0, 0, 4112, 0, 0, 0, 7, 
28672, 0, 0, 0, 2056, 0, 0, 14, 
14336, 0, 0, 0, 0, 1028, 0, 14, 
14336, 0, 0, 0, 0, 0, 514, 7, 
14336, 0, 0, 0, 0, 257, 0, 7, 
14336, 0, 0, 0, 514, 0, 0, 7, 
28672, 0, 0, 1028, 0, 0, 0, 7, 
28672, 0, 2056, 0, 0, 0, 0, 7, 
14336, 4112, 0, 0, 0, 0, 0, 7, 
14336, 0, 8224, 0, 0, 0, 0, 7, 
14336, 0, 0, 8224, 0, 0, 0, 7, 
14336, 0, 0, 0, 16448, 0, 0, 14, 
14336, 0, 0, 0, 0, 16448, 0, 28, 
14336, 0, 0, 0, 0, 0, 16448, 56, 
14336, 0, 0, 0, 0, 0, 0, 33008, 
14336, 0, 0, 0, 0, 0, 0, 112, 
14336, 0, 0, 0, 0, 0, 0, 0, 
14336, 0, 0, 0, 0, 0, 0, 112, 
14336, 0, 0, 0, 0, 0, 0, 0, 
14336, 0, 0, 0, 0, 0, 0, 112, 
247, 148, 178, 4, 119, 160, 167, 117, 
247, 148, 178, 4, 119, 160, 167, 117, 
247, 148, 178, 4, 119, 160, 167, 117, 
65311, 46357, 61713, 0, 49167, 8202, 49157, 0, 
65311, 46357, 61713, 0, 49167, 8202, 49157, 0, 
65311, 46357, 61713, 0, 49167, 8202, 49157, 0, 
 };






const unsigned int anim2[] PROGMEM  = {8, 1 , 15564, 7782, 3891, 34713, 50124, 57702, 61491, 30873, 
30873, 15564, 7782, 3891, 34713, 50124, 57702, 61491, 
61491, 30873, 15564, 7782, 3891, 34713, 50124, 57702, 
57702, 61491, 30873, 15564, 7782, 3891, 34713, 50124, 
50124, 57702, 61491, 30873, 15564, 7782, 3891, 34713, 
34713, 50124, 57702, 61491, 30873, 15564, 7782, 3891, 
3891, 34713, 50124, 57702, 61491, 30873, 15564, 7782, 
7782, 3891, 34713, 50124, 57702, 61491, 30873, 15564, 
 };


unsigned int sklenicka[] PROGMEM = {1, 60 | PLAY_ONCE, 24576, 20736, 22800, 26424, 18768, 53632, 24576, 0, 
 };

 unsigned int panacekAhoj[] PROGMEM = {2, 20 , 0, 1024, 24841, 37390, 37390, 24841, 1024, 0, 
0, 1024, 24841, 37390, 37390, 24841, 4096, 0, 
 };

unsigned const int smajlik[] PROGMEM = {2, 15 , 15420, 16962, 37249, 33157, 33157, 37249, 16962, 15420, 15420, 16962, 37253, 33159, 33159, 37253, 16962, 15420,  };

const char hub_text[] PROGMEM = "HELLO WORLD! ";
const unsigned int hub[] PROGMEM ={0,2 , strlen(hub_text), &hub_text};

const char hub_text2[] PROGMEM = "AHOJ SVETE! ";
const unsigned int hub2[] PROGMEM ={0,2, strlen(hub_text2), &hub_text2};



#define TEXT_MODE 0
#define ANIM_MODE 1

unsigned char actMode;
unsigned int znaky[] = {0, 0, 0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,};


#define ANIM_HEADER_SIZE 2

volatile unsigned int *animList[] = {buffer, allColors, anim2, sklenicka, smajlik, panacekAhoj, tengu, hub, hub2 };
//unsigned int *animList[] = {allColors};


#define animCount (sizeof(animList)/2)



volatile unsigned int cycle = 0, cycle2 = 0, cycleText = 0, actZnak = 0, actZnakCol = 0;
volatile unsigned char actCol = 0;
volatile unsigned int  actFrame = 0;
volatile unsigned int  actAnim = 0;

volatile unsigned char nextAnimFlag = 0;
volatile char actChar;
volatile char *chrPtr;

volatile unsigned int scrollSpeed;
volatile unsigned int mem;
volatile unsigned int actTextLength = 7;

volatile unsigned char i;



ISR(TIMER0_OVF_vect )
{



ADCSRA |=  _BV(ADSC);

	if(pgm_read_word(&animList[actAnim][0]) == 0)
	{	
		actMode = TEXT_MODE;
	}
	else
		actMode = ANIM_MODE;

	if(actMode == ANIM_MODE)
	{
	// Dal�� frame
	cycle++;
	if(cycle > (pgm_read_word(&animList[actAnim][1]) & 0x7FFF))
	{
		cycle = 0;
		actFrame++;
		if(actFrame == pgm_read_word(&animList[actAnim][0]))
		{
			actFrame = 0;
			if((pgm_read_word(&animList[actAnim][1]) & _BV(15)))
			{
				nextAnimFlag = 1;
			}
		}
	}

	// Dal�� animace
	cycle2++;
	if((cycle2 > 120 && animCount > 1 && (!(pgm_read_word(&animList[actAnim][1]) & 0x8000))) || nextAnimFlag)
	{
		cycle2=0;
		actAnim++;
		if(actAnim == animCount)
		{
			actAnim = 0;
			
		}
		actFrame = 0;
			cycle = 0;
			nextAnimFlag=0;
			//actCol = 0;
	}
	}  if(actMode == TEXT_MODE) {

		cycleText++;

		scrollSpeed = pgm_read_word(&animList[actAnim][1]);
		if(cycleText == (scrollSpeed & 0x7FFF))
		{
			cycleText = 0;
			znaky[0 + 2] = znaky[1 + 2];
			znaky[1 + 2] = znaky[2 + 2];
			znaky[2 + 2] = znaky[3 + 2];
			znaky[3 + 2] = znaky[4 + 2];
			znaky[4 + 2] = znaky[5 + 2];
			znaky[5 + 2] = znaky[6 + 2];
			znaky[6 + 2] = znaky[7 + 2];


			mem = (int)animList[actAnim];
			actTextLength = pgm_read_word(mem +  2*2);

			mem = pgm_read_word(mem +  3*2);
			

			mem = mem + actZnak;

			//if(actZnak % 2 == 0)
				//actChar = *((char *)(pgm_read_byte(mem)) );
				actChar = pgm_read_word(mem);
		//	else
			//	actChar = *((char *)pgm_read_word(mem + actZnak));


			if(actZnakCol != 5)
				znaky[7 + 2] = pgm_read_byte(&font[actChar-' '][actZnakCol]);
			else
				znaky[7 + 2] = 0;

			if(actZnakCol % 2 == 0)
			{
				znaky[7 + 2] = znaky[7 + 2]  << 8;
			}
			if(actZnakCol % 3 == 0)
			{
				znaky[7 + 2] = znaky[7 + 2] | znaky[7 + 2] << 8;
			}


				
			actZnakCol++;
			if(actZnakCol == 6)
			{
				actZnakCol = 0;
				actZnak++;

				

				if(actZnak == actTextLength)
				{
					actZnak =0;
					actZnakCol = 0;
					for(i = 0; i < 10; i++)
						znaky[i] = 0x0000;
					actAnim++;
					if(actAnim == animCount)
					{
						actAnim = 0;
					}
				}
			}	

		}


	}	


}



void setCol(unsigned char col)
{

	DDRA &= ~_BV(PINA2); //3
	DDRA &= ~_BV(PINA5); //2
	DDRC &= ~_BV(PINC7); //1
	DDRC &= ~_BV(PINC4); //0

	DDRC &= ~_BV(PINC3);
	DDRC &= ~_BV(PINC0);
	DDRD &= ~_BV(PIND5);
	DDRD &= ~_BV(PIND2);


	switch(col)
	{

		case 0:
			DDRC |= _BV(PINC4);
			break;

		case 1:
			DDRC |= _BV(PINC7);
			break;

		case 2:
			DDRA |= _BV(PINA5);
			break;

		case 3:
			DDRA |= _BV(PINA2);
			break;

		case 4:
			DDRC |= _BV(PINC3);
			break;

		case 5:
			DDRC |= _BV(PINC0);
			break;

		case 6:
			DDRD |= _BV(PIND5);
			break;

		case 7:
			DDRD |= _BV(PIND2);
			break;



	}

}



int main(void)
{



TCCR0 |= _BV(CS00) | _BV(CS02);
TIMSK |= _BV(TOIE0);

sei();

unsigned int mask = 0xaa55;


PORTA = _BV(1) | _BV(3) | _BV(4) | _BV(6) | _BV(7);
PORTB = _BV(0) | _BV(PB2); // PB2 - buttonek
PORTC = _BV(6) | _BV(5) | _BV(2) | _BV(1);
PORTD = _BV(7) | _BV(6) | _BV(4) | _BV(3) | _BV(1) | _BV(0);

GICR = _BV(INT2);

ADMUX = _BV(ADLAR) | _BV(REFS0);

ADCSRA = _BV(ADEN) | _BV(ADSC);

delay_ms(250);
delay_ms(250);

for(;;)
{



if(actMode == ANIM_MODE)
	mask = pgm_read_word(&(animList[actAnim])[actCol + actFrame * 8 + ANIM_HEADER_SIZE]);
else
	mask = znaky[actCol + actFrame * 8 + ANIM_HEADER_SIZE];


DDRA = 0x00;
DDRB = 0x00;
DDRC = 0x00;
DDRD = 0x00;

setCol(actCol);
actCol++;
actCol = actCol % 8;




if(bit_is_clear(PINB, PB2))
{
	DDRA = 0x00;
	DDRB = 0x00;
	DDRC = 0x00;
	DDRD = 0x00;

	set_sleep_mode(SLEEP_MODE_PWR_DOWN); //set sleep mode
    sleep_mode(); //sleep now

	delay_ms(250);
}



// r1r
DDRD |= (mask & _BV(15)) ? _BV(0) : 0;
// r1g
DDRD |= (mask & _BV(7)) ? _BV(1) : 0;

// r2r
DDRD |= (mask & _BV(14)) ? _BV(3) : 0;
// r2g
DDRD |= (mask & _BV(6)) ? _BV(4) : 0;

// r3r
DDRD |= (mask & _BV(13)) ? _BV(6) : 0;
// r3r
DDRD |= (mask & _BV(5)) ? _BV(7) : 0;

// r4r
DDRC |= (mask & _BV(12)) ?  _BV(1) : 0;
// r4r
DDRC |= (mask & _BV(4)) ? _BV(2) : 0;

// r5r
DDRB |= (mask & _BV(11)) ? _BV(0) : 0;
// r5g
DDRA |= (mask & _BV(3)) ? _BV(1) : 0;

// r6r
DDRA |= (mask & _BV(10)) ? _BV(3) : 0;
// r6g
DDRA |= (mask & _BV(2)) ? _BV(4) : 0;

// r7r
DDRA |= (mask & _BV(9)) ? _BV(6) : 0;
// r7g
DDRA |= (mask & _BV(1)) ? _BV(7) : 0;

// r8r
DDRC |= (mask & _BV(8)) ? _BV(6) : 0;
// r8g
DDRC |= (mask & _BV(0)) ? _BV(5) : 0;


delay_us(200);



}

              
    
}


