#include "inc/lm3s6965.h"
#include "inc/hw_types.h"
#include "driverlib/gpio.h"
#include "driverlib/sysctl.h"
#include "inc/hw_memmap.h"

// Evalbot hello world - blinking
// Martin Hubacek
// electronics.martinhubacek.cz

// System timer interrupt
// look in gcc_Startup.c a search for SysTickHandler to
// understand how work with interrupts
void SysTickHandler()
{
  // Invert pin4
  GPIO_PORTF_DATA_R ^= 0x01 << 4;
}


void main(void)
{
  // Enable systick - system timer
  SysTickPeriodSet(SysCtlClockGet() / 1);
  SysTickEnable();
  SysTickIntEnable();

   // LED is on pin PF4
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);
	GPIOPinTypeGPIOOutput(GPIO_PORTF_BASE, GPIO_PIN_4);

  // Main program does nothing so do an infinte loop
  while(1);
  
}


