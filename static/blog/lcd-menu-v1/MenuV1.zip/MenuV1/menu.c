
#include "lcd.h"

// www.martinhubacek.cz
// Martin Hub��ek 21.4.2012

#define  lcd_clrscr LcdClear
#define lcd_gotoxy gotoXY
#define lcd_puts LcdString
#define lcd_putc LcdCharacter

#include "ustdlib.h"
#include "menu.h"
#include "keyboard.h"


char actualLanguage = LANGUAGE_CZECH;


volatile int menuPreselect = -1;

/*
 * Displays simple menu
 *
 * @array - array of strings, the first string in array is menu title
 * 			WARNING - the array has to have the NULL/0 as the last item!!
 *
 * eg.: 	static char *mainMenu[] = { "Menu title", "First item", "Second item", 0};
 *
 * 			switch(showMenu(mainMenu))
 * 			{
 * 				case 0:
 * 					// First item selected
 * 					break;
 * 				case 1:
 * 					// Second item selected
 * 					break;
 * 			}
 *
 * Global value actualLanguage selects the language
 * 			static char *mainMenu[] = { "Language 0 title", "lang0 item", "lang0 item", 0,
 * 										"Language 1 title", "lang1 item", "lang1 item", 0};
 *
 * Global value menuPreselect preselects item in menu before calling showMenu,
 *  			if menuPreselect = -1 then this option is disabled
 *
 *
 * return - index of the selected item or -1 if exit was pressed
 * 			Notice that the return code 0 corresponds to item array[1]
 * 			in the array passed by the parameter - because of the menu title in array[0]
 */
int showMenu(char *array[]) {

	unsigned char menuItem = 0;
	unsigned char lastMenuItem = 255;

	unsigned char cursorTopPos = 0;
	unsigned char menuTopPos = 0;
	char **iList = array;

	unsigned char i;
  
	//unsigned char buffer[20];

	//
	// Get number of items in menu, search for the first NULL
	//
	int len = -1;
	for (; *iList != 0; ++iList)
	  len++;

	// Functional :)
	// menuItem, menuTopPos, cursorTopPos
	if(menuPreselect != -1)
	{
	  // If item on the first screen
	  if(menuPreselect < MENU_LINES)
	  {
		  menuItem = menuPreselect;
		  cursorTopPos = menuPreselect;
		  menuTopPos = 0;
	  } else {
		 // Item is on other screen
		  menuItem = menuPreselect;
		  cursorTopPos = MENU_LINES - 1;
		  menuTopPos = menuPreselect - cursorTopPos;
	  }
	}


	//
	// Switch pointer to actual language
	//
	array += actualLanguage * (len + 2);


	// Main menu loop
	for(;;) {

		// If your system allows idle mode
		#ifdef SLEEP
			SysCtlSleep();
		#endif

		if(keyPress) {
			
		  //
		  // Down
		  //
		if(keyPress == BTN_DOWN)
		  {
			if(menuItem != len-1)
			{
			menuItem++;

			if(cursorTopPos >= MENU_LINES-1)
			  menuTopPos++;
			else
			  cursorTopPos++;

			} else {
				menuItem = 0;
				cursorTopPos = 0;
				menuTopPos = 0;
			}
		  }

		  //
		  // Up
		  //
		 if(keyPress == BTN_UP)
		  {
			if(menuItem != 0)
			{
			menuItem--;

			if(cursorTopPos > 0)
			  cursorTopPos--;
			else
			  menuTopPos--;
			  } else {
				menuItem = len-1;

				if(len <= MENU_LINES)
				{
					menuTopPos = 0;
				} else {
					menuTopPos = menuItem;
				}
				if(menuTopPos > len - MENU_LINES && len >= MENU_LINES)
				{
					menuTopPos = len - MENU_LINES;
				}

				cursorTopPos = menuItem - menuTopPos;
			  }
		  }


		  //
		  // Enter
		  //
		 if(keyPress == BTN_ENTER || keyPress == BTN_RIGHT)
		  {
			keyPress = 0;
			menuPreselect = -1;
					return menuItem;
		  }


		  //
		  // Left - back
		  //
		  if(keyPress == BTN_LEFT)
		  {
			keyPress = 0;
			menuPreselect = -1;
					return -1;
		  }

				keyPress = 0;

			} // if(keyPress)

		//
		// If menu item changed -> refresh screen
		//
		if(lastMenuItem != menuItem)
		{
		  displayClear();
		  displayString(array[0],0,0);

		  // Menu debug
		  //sprintf(buffer, "%d,%d,%d", menuItem, menuTopPos, cursorTopPos);
		  //displayString(buffer,0,0);

		  i = 0;
		  while((i + menuTopPos) < len &&   i < MENU_LINES)
		  {
			if(menuItem == i + menuTopPos && MENU_LINES > 1)
				displayString(ARROW_SYMBOL, 0, ROW(i+1));

			if(MENU_LINES > 1)
				displayString(array[menuTopPos + i + 1], COL(1+ARROW_GAP), ROW(i+1));
			else
				displayString(array[menuTopPos + i + 1], COL(0), ROW(i+1));

			i++;
		  }

			#ifdef displayDraw
			  displayDraw();
			#endif

		  lastMenuItem = menuItem;
		}

			
	}   
	
	return 0;
}


/*
 * Temperature edit dialog
 * str - text to display
 * temp - pointer to the temperature, WARNING it's in decicelsius:
 * 			value 326 means = 32,6�C
 * 			value -15 means = -1,5�C
 * increment - increment, for editing celsius number enter 10
 * 							for editing thenth of celesius enter 1
 *
 * returns - 1 if user pressed key right
 * 			0 if user pressed key left
 */
#ifdef MENU_EDIT_TEMPERATURE
uint8_t menuEditTemp(const char* str, int* temp, int increment)
{
	int editTemp = *temp;

	for(;;)
	{

	displayClear();
	displayString(str, 0, 0);

	lcd_gotoxy(2,1);
	//displayNumber(editTemp, 1);

	while(keyPress == 0);

	switch(keyPress)
	{

		case BTN_UP:
			keyPress = 0;
			editTemp += increment;
			break;

		case BTN_DOWN:
			keyPress = 0;
			editTemp -= increment;
			break;

		case BTN_RIGHT:
			keyPress = 0;
			*temp = editTemp;
			return 1;
			break;

		case BTN_LEFT:
			keyPress = 0;
			return 0;
			break;

	}
	}
}
#endif //MENU_EDIT_TEMPERATURE

/*
 * Time edit dialog
 * str - Instruction text
 * pHourst - pointer to the hours
 * pMinutes - pointer to the minutes
 *
 * returns -  1 if the user confirmed value by pressing BTN_RIGHT
 * 			  0 if the user pressed BTN_LEFT
 */
#ifdef MENU_EDIT_TIME
int8_t menuEditTime(char *str, uint8_t* pHours, uint8_t* pMinutes)
{
	int8_t hours, minutes, deciMinutes;

	unsigned char editPos = 0;
	unsigned char editGoto[] = {1, 3, 4};

	unsigned char relX = 4, relY = 3;

	hours = *pHours;
	minutes = *pMinutes % 10;
	deciMinutes = *pMinutes / 10;


	for(;;)
	{
		lcdBufferClear();
		lcdBufferString(str, COL(0),ROW(1));

		lcdBufferDrawUnderline((editPos == 0) ? 1 : 0);
		lcdBufferNumber2(hours, COL(relX), ROW(relY));

		lcdBufferDrawUnderline(0);
		lcdBufferString(":", COL(relX+2), ROW(relY));

		lcdBufferDrawUnderline((editPos == 1) ? 1 : 0);
		lcdBufferNumber(deciMinutes, COL(relX+3), ROW(relY));
		lcdBufferDrawUnderline((editPos == 2) ? 1 : 0);
		lcdBufferNumber(minutes, COL(relX+4), ROW(relY));

		lcdBufferDrawUnderline(0);
		//lcd_gotoxy(editGoto[editPos] + relX, relY);
		
		lcdBufferDraw();

		//lcd_command(LCD_DISP_ON_CURSOR);

		while(keyPress == 0);

		//lcd_command(LCD_DISP_ON);

		switch(keyPress)
		{
			case BTN_LEFT:
				keyPress = 0;
				if(editPos == 0)
					return 0;
				editPos--;
				break;

			case BTN_RIGHT:
				keyPress = 0;
				if(editPos == 2)
				{
					*pHours = hours;
					*pMinutes = deciMinutes*10 + minutes;
					return 1;
				}
				editPos++;
				break;

			case BTN_UP:
				keyPress = 0;
				if(editPos == 0)
				{
					hours++;
					if(hours > 23)
						hours = 0;
				}
				if(editPos == 1)
				{
					deciMinutes++;
					if(deciMinutes > 5)
						deciMinutes = 0;
				}
				if(editPos == 2)
				{
					minutes++;
					if(minutes > 9)
						minutes = 0;
				}
				break;

			case BTN_DOWN:
				keyPress = 0;
				if(editPos == 0)
				{
					hours--;
					if(hours < 0)
						hours = 23;
				}
				if(editPos == 1)
				{
					deciMinutes--;
					if(deciMinutes < 0)
						deciMinutes = 5;
				}
				if(editPos == 2)
				{
					minutes--;
					if(minutes < 0)
						minutes = 9;
				}
				break;

			default:
				keyPress = 0;
				break;

		}

	}
}
#endif // MENU_EDIT_TIME


//
// Shows text on screen and wait for any keypress
//
int8_t menuMsgBox(const char *str)
{
	displayClear();
	displayString(str,0,0);
	displayDraw();

	while(keyPress == 0);
	keyPress = 0;

	return 1;

}

/*
 * Edit number by pressing keys up/down
 *
 * str - string with instructions
 * val - pointer to the edited value
 * unit - string useful for units (m, kg..), displays behind the number
 * inc - increment/decrement
 * valMin - minimal value, inclusive
 * valMax - maximal value, inclusive
 *
 * returns - 1 if user confirmed edited number by BTN_RIGHT
 * 		   - 0 if user pressed key BTN_LEFT
 */
#ifdef MENU_EDIT_NUMBER
uint8_t menuEditNumber(const char *str, int16_t *val, const char *unit, uint8_t inc, int16_t valMin, int16_t valMax)
{
	int16_t actVal = *val;
	int16_t posx = COL(0);
	int16_t posy = ROW(0);

	for(;;)
	{
		displayClear();
		displayString(str, posx, posy);
		displayNumber(actVal, posx + COL(strlen(str)), posy);
		displayString(unit, posx + COL(strlen(str) + 3), posy);

		displayDraw();

		while(keyPress == 0);

		switch(keyPress)
		{
			case BTN_LEFT:
				keyPress = 0;
				return 0;
				break;
			
			case BTN_RIGHT:
				keyPress = 0;
				*val = actVal;
				return 1;
				break;

			case BTN_UP:
				keyPress = 0;
				if(actVal + inc <= valMax)
					actVal += inc;
				break;


			case BTN_DOWN:
				keyPress = 0;
				if(actVal - inc >= valMin)
					actVal -= inc;
				break;

		}

	}
}
#endif //MENU_EDIT_NUMBER
