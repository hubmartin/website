﻿namespace WindowsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該公開 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改這個方法的內容。
        ///
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.progressL = new System.Windows.Forms.ProgressBar();
            this.progressR = new System.Windows.Forms.ProgressBar();
            this.scr0 = new System.Windows.Forms.HScrollBar();
            this.scr1 = new System.Windows.Forms.HScrollBar();
            this.scr2 = new System.Windows.Forms.HScrollBar();
            this.scr3 = new System.Windows.Forms.HScrollBar();
            this.scr4 = new System.Windows.Forms.HScrollBar();
            this.scr5 = new System.Windows.Forms.HScrollBar();
            this.scr7 = new System.Windows.Forms.HScrollBar();
            this.scr6 = new System.Windows.Forms.HScrollBar();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.lstAlgorithms = new System.Windows.Forms.ListBox();
            this.tmrReconnect = new System.Windows.Forms.Timer(this.components);
            this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
            this.trayMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.obnovitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.trcPwm = new System.Windows.Forms.TrackBar();
            this.chckAuto = new System.Windows.Forms.CheckBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.trayMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trcPwm)).BeginInit();
            this.SuspendLayout();
            // 
            // timer
            // 
            this.timer.Enabled = true;
            this.timer.Interval = 10;
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // progressL
            // 
            this.progressL.Location = new System.Drawing.Point(59, 12);
            this.progressL.Maximum = 128;
            this.progressL.Name = "progressL";
            this.progressL.Size = new System.Drawing.Size(386, 23);
            this.progressL.TabIndex = 3;
            // 
            // progressR
            // 
            this.progressR.Location = new System.Drawing.Point(59, 194);
            this.progressR.Maximum = 128;
            this.progressR.Name = "progressR";
            this.progressR.Size = new System.Drawing.Size(386, 23);
            this.progressR.TabIndex = 3;
            // 
            // scr0
            // 
            this.scr0.Location = new System.Drawing.Point(59, 172);
            this.scr0.Maximum = 128;
            this.scr0.Name = "scr0";
            this.scr0.Size = new System.Drawing.Size(386, 19);
            this.scr0.TabIndex = 5;
            this.scr0.Value = 15;
            // 
            // scr1
            // 
            this.scr1.Location = new System.Drawing.Point(59, 153);
            this.scr1.Maximum = 128;
            this.scr1.Name = "scr1";
            this.scr1.Size = new System.Drawing.Size(386, 19);
            this.scr1.TabIndex = 6;
            this.scr1.Value = 30;
            // 
            // scr2
            // 
            this.scr2.Location = new System.Drawing.Point(59, 134);
            this.scr2.Maximum = 128;
            this.scr2.Name = "scr2";
            this.scr2.Size = new System.Drawing.Size(386, 19);
            this.scr2.TabIndex = 7;
            this.scr2.Value = 45;
            // 
            // scr3
            // 
            this.scr3.Location = new System.Drawing.Point(59, 115);
            this.scr3.Maximum = 128;
            this.scr3.Name = "scr3";
            this.scr3.Size = new System.Drawing.Size(386, 19);
            this.scr3.TabIndex = 8;
            this.scr3.Value = 60;
            // 
            // scr4
            // 
            this.scr4.Location = new System.Drawing.Point(59, 96);
            this.scr4.Maximum = 128;
            this.scr4.Name = "scr4";
            this.scr4.Size = new System.Drawing.Size(386, 19);
            this.scr4.TabIndex = 9;
            this.scr4.Value = 75;
            // 
            // scr5
            // 
            this.scr5.Location = new System.Drawing.Point(59, 76);
            this.scr5.Maximum = 128;
            this.scr5.Name = "scr5";
            this.scr5.Size = new System.Drawing.Size(386, 19);
            this.scr5.TabIndex = 12;
            this.scr5.Value = 90;
            // 
            // scr7
            // 
            this.scr7.Location = new System.Drawing.Point(59, 38);
            this.scr7.Maximum = 128;
            this.scr7.Name = "scr7";
            this.scr7.Size = new System.Drawing.Size(386, 19);
            this.scr7.TabIndex = 11;
            this.scr7.Value = 115;
            // 
            // scr6
            // 
            this.scr6.Location = new System.Drawing.Point(59, 57);
            this.scr6.Maximum = 128;
            this.scr6.Name = "scr6";
            this.scr6.Size = new System.Drawing.Size(386, 19);
            this.scr6.TabIndex = 10;
            this.scr6.Value = 104;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(25, 13);
            this.label1.TabIndex = 13;
            this.label1.Text = "Left";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(19, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(13, 13);
            this.label2.TabIndex = 13;
            this.label2.Text = "7";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(19, 63);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(13, 13);
            this.label3.TabIndex = 13;
            this.label3.Text = "6";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(19, 82);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(13, 13);
            this.label4.TabIndex = 13;
            this.label4.Text = "5";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(19, 102);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(13, 13);
            this.label5.TabIndex = 13;
            this.label5.Text = "4";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(19, 121);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(13, 13);
            this.label6.TabIndex = 13;
            this.label6.Text = "3";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(19, 140);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(13, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "2";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(19, 159);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(13, 13);
            this.label8.TabIndex = 13;
            this.label8.Text = "1";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(19, 178);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(13, 13);
            this.label9.TabIndex = 13;
            this.label9.Text = "0";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(19, 204);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(32, 13);
            this.label11.TabIndex = 13;
            this.label11.Text = "Right";
            // 
            // lstAlgorithms
            // 
            this.lstAlgorithms.FormattingEnabled = true;
            this.lstAlgorithms.Items.AddRange(new object[] {
            "byChange",
            "byMaxValue",
            "byChangeAvg"});
            this.lstAlgorithms.Location = new System.Drawing.Point(451, 12);
            this.lstAlgorithms.Name = "lstAlgorithms";
            this.lstAlgorithms.Size = new System.Drawing.Size(74, 199);
            this.lstAlgorithms.TabIndex = 14;
            // 
            // tmrReconnect
            // 
            this.tmrReconnect.Enabled = true;
            this.tmrReconnect.Interval = 1000;
            this.tmrReconnect.Tick += new System.EventHandler(this.tmrReconnect_Tick);
            // 
            // notifyIcon1
            // 
            this.notifyIcon1.ContextMenuStrip = this.trayMenu;
            this.notifyIcon1.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIcon1.Icon")));
            this.notifyIcon1.Text = "VuUSB";
            this.notifyIcon1.Visible = true;
            this.notifyIcon1.DoubleClick += new System.EventHandler(this.notifyDblClick);
            // 
            // trayMenu
            // 
            this.trayMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.obnovitToolStripMenuItem});
            this.trayMenu.Name = "trayMenu";
            this.trayMenu.Size = new System.Drawing.Size(124, 26);
            // 
            // obnovitToolStripMenuItem
            // 
            this.obnovitToolStripMenuItem.Name = "obnovitToolStripMenuItem";
            this.obnovitToolStripMenuItem.Size = new System.Drawing.Size(123, 22);
            this.obnovitToolStripMenuItem.Text = "Obnovit";
            this.obnovitToolStripMenuItem.Click += new System.EventHandler(this.obnovitToolStripMenuItem_Click);
            // 
            // trcPwm
            // 
            this.trcPwm.Location = new System.Drawing.Point(531, 11);
            this.trcPwm.Maximum = 255;
            this.trcPwm.Minimum = 1;
            this.trcPwm.Name = "trcPwm";
            this.trcPwm.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.trcPwm.Size = new System.Drawing.Size(45, 180);
            this.trcPwm.SmallChange = 10;
            this.trcPwm.TabIndex = 16;
            this.trcPwm.TickFrequency = 20;
            this.trcPwm.Value = 50;
            this.trcPwm.Scroll += new System.EventHandler(this.trcPwm_Scroll);
            // 
            // chckAuto
            // 
            this.chckAuto.AutoSize = true;
            this.chckAuto.Location = new System.Drawing.Point(531, 194);
            this.chckAuto.Name = "chckAuto";
            this.chckAuto.Size = new System.Drawing.Size(48, 17);
            this.chckAuto.TabIndex = 17;
            this.chckAuto.Text = "Auto";
            this.chckAuto.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(343, 236);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 18;
            this.button1.Text = "Stop";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(218, 223);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 18;
            this.button2.Text = "Start";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(602, 271);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.chckAuto);
            this.Controls.Add(this.trcPwm);
            this.Controls.Add(this.lstAlgorithms);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.scr5);
            this.Controls.Add(this.scr7);
            this.Controls.Add(this.scr6);
            this.Controls.Add(this.scr4);
            this.Controls.Add(this.scr3);
            this.Controls.Add(this.scr2);
            this.Controls.Add(this.scr1);
            this.Controls.Add(this.scr0);
            this.Controls.Add(this.progressR);
            this.Controls.Add(this.progressL);
            this.Name = "Form1";
            this.Text = "VuUSB commander";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.formClose);
            this.Resize += new System.EventHandler(this.resize);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.trayMenu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.trcPwm)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Timer timer;
        private System.Windows.Forms.ProgressBar progressL;
        private System.Windows.Forms.ProgressBar progressR;
        private System.Windows.Forms.HScrollBar scr0;
        private System.Windows.Forms.HScrollBar scr1;
        private System.Windows.Forms.HScrollBar scr2;
        private System.Windows.Forms.HScrollBar scr3;
        private System.Windows.Forms.HScrollBar scr4;
        private System.Windows.Forms.HScrollBar scr5;
        private System.Windows.Forms.HScrollBar scr7;
        private System.Windows.Forms.HScrollBar scr6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ListBox lstAlgorithms;
        private System.Windows.Forms.Timer tmrReconnect;
        private System.Windows.Forms.NotifyIcon notifyIcon1;
        private System.Windows.Forms.ContextMenuStrip trayMenu;
        private System.Windows.Forms.ToolStripMenuItem obnovitToolStripMenuItem;
        private System.Windows.Forms.TrackBar trcPwm;
        private System.Windows.Forms.CheckBox chckAuto;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}

