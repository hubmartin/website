using System;
using System.Collections.Generic;
using System.Text;

namespace WindowsApplication1
{
	public static class soundAlgorithms
	{
		public static void byChange(byte[] CaptureData, ref int vuL, ref int vuR)
	    {
			int intAudioL, intAudioR;
			int sglDifferenceL, sglDifferenceR;
			int sglValueL = 0, sglValueR = 0;

			for(int i = 0; i < 256; i++)
			{
				intAudioL = CaptureData[i * 2] - 127;
				intAudioR = CaptureData[i * 2 + 1] - 127;

				if(intAudioL < 0)
					intAudioL = 0;
				if(intAudioR < 0)
					intAudioR = 0;

				  //'calculate the change
				  sglDifferenceL = intAudioL - sglValueL;
				  sglDifferenceR = intAudioR - sglValueR;
				  //'attack
				  if( sglDifferenceL > 0 )sglValueL = sglValueL + (sglDifferenceL / 10); //20
				  if (sglDifferenceR > 0 )sglValueR = sglValueR + (sglDifferenceR / 10);
				  //'decay
				  if (sglDifferenceL < 0 ) sglValueL = sglValueL + (sglDifferenceL / 1000); // 1000
				  if (sglDifferenceR < 0 ) sglValueR = sglValueR + (sglDifferenceR / 1000);
				
			}

			vuL = (int)((sglValueL * sglValueL) / 128);
			vuR = (int)((sglValueR * sglValueR) / 128);
		}

        static List<int> avgL;
        static List<int> avgR;

        public static void byChangeAvg(byte[] CaptureData, ref int vuL, ref int vuR)
	    {
			int intAudioL, intAudioR;
			int sglDifferenceL, sglDifferenceR;
			int sglValueL = 0, sglValueR = 0;

            if (avgL == null)
            {
                avgL = new List<int>();
                avgR = new List<int>();
            }

			for(int i = 0; i < 256; i++)
			{
				intAudioL = CaptureData[i * 2] - 127;
				intAudioR = CaptureData[i * 2 + 1] - 127;

				if(intAudioL < 0)
					intAudioL = 0;
				if(intAudioR < 0)
					intAudioR = 0;

				  //'calculate the change
				  sglDifferenceL = intAudioL - sglValueL;
				  sglDifferenceR = intAudioR - sglValueR;
				  //'attack
				  if( sglDifferenceL > 0 )sglValueL = sglValueL + (sglDifferenceL / 20);
				  if (sglDifferenceR > 0 )sglValueR = sglValueR + (sglDifferenceR / 20);
				  //'decay
				  if (sglDifferenceL < 0 ) sglValueL = sglValueL + (sglDifferenceL / 10000);
				  if (sglDifferenceR < 0 ) sglValueR = sglValueR + (sglDifferenceR / 10000);
				
			}

			vuL = (int)((sglValueL * sglValueL) / 128);
			vuR = (int)((sglValueR * sglValueR) / 128);

            avgL.Add(vuL);
            avgR.Add(vuR);

            int samples = 2;

            if (avgL.Count > samples)
                avgL.RemoveAt(0);
            if (avgR.Count > samples)
                avgR.RemoveAt(0);

            int averageLeft = 0;
            for(int i = 0; i < avgL.Count; i++)
                averageLeft += avgL[i];
            averageLeft = averageLeft / avgL.Count;

            int averageRight = 0;
            for(int i = 0; i < avgR.Count; i++)
                averageRight += avgR[i];
            averageRight = averageRight / avgR.Count;

            vuL = averageLeft;
            vuR = averageRight;

		}


        public static void byMaxValue(byte[] CaptureData, ref int vuL, ref int vuR)
        {

            vuL = 0;
            vuR = 0;

            for (int i = 0; i < 256; i++)
            {
                if (CaptureData[i * 2] - 127 > vuL)
                    vuL = CaptureData[i * 2] - 127;
                if (CaptureData[i * 2+1] - 127 > vuR)
                    vuR = CaptureData[i * 2 + 1] - 127;
            }

        }
	}
}
