using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using Microsoft.DirectX;
using Microsoft.DirectX.DirectSound;
using System.Threading;
using ICSharpCode.USBlib;

namespace WindowsApplication1
{

    

    public partial class Form1 : Form
    {
        // To Set the capture offset and use later
        int mycapoffset = 0;
        
        // To define the wavformat (Used at startcap())
        WaveFormat mywavform;

        // Default the path of thw wav FILE for convenient (Used at WriteFileHeader())
        string mysavefilename = @"c:\test.wav";

        // Create a Brinary Write for file write (Used at WriteFileHeader())
        BinaryWriter m_Writer = null;

        // Create a Thread for the recording task (Used at BeginCapturing())
        Thread mythread;
        AutoResetEvent m_NotificationEvent = null;

        // NumberRecordNotifications (Used at startcap() && BeginCapturing())
        int NumberRecordNotifications = 16;

        // BufferPositionNotify (Used at BeginCapturing() && Set at initial)
        BufferPositionNotify[] m_PositionNotify = null;
        int notifysize = 0;
        Notify m_Notify = null;

        // Creat Capturebuffer (Used at startcap() && BeginCapturing())
        CaptureBuffer mycapbuff;

        // Is capturing?
        bool m_Capturing = false;
        int vuL = 0;
        int vuR = 0;
        int selAlgorithm;

        bool isConnected = false;


        // The capturingBuffer Size (Used at startcap() && Waitthread())
        int mycapbuffsize = 0;

        // SampleCount (Used at writefiletruck())
        int m_SampleCount = 0;

        // To set the buffer
        Capture mycap;

        ICSharpCode.USBlib.Device dev;

        public Form1()
        {
            InitializeComponent();
            m_PositionNotify = new BufferPositionNotify[NumberRecordNotifications + 1];
        }


        public void openDevice()
        {
            try
            {
                foreach (Bus bus in Bus.Busses)
                {
                    Console.WriteLine(bus.DirectoryName);

                    foreach (Descriptor descriptor in bus.Descriptors)
                    {
                        if (descriptor.ProductId == 0x05DC && descriptor.VendorId == 0x16C0)
                        {
                            dev = descriptor.OpenDevice();
                            isConnected = true;
                        }
                    }
                }
            }
            catch (Exception e)
            { }
        }

        public void closeDevice()
        {
            try
            {
                dev.Close();
                dev.Dispose();
            }
            catch (Exception e)
            { }
        }

        public void sendDevice(int command, int value)
        {
            //int send = (byte)left | (((byte)right) << 8);
            try
            {

                dev.SendControlMessage((0x02 << 5) | 0 | 0x80, command, value, null);
            }
            catch (Exception e)
            {
                isConnected = false;

                //dev.Close();
                //dev.Dispose();


            }
        }


        //start cap
        private void startcap()
        {

            // Open USB device
            //openDevice();

            // TO capture the MIC or Device
            // 1. To select the source
            // To Capture thought Device
            mycap = new Capture(DSoundHelper.DefaultCaptureDevice);
            // OR To Capture thought Mic
            //Caputre mycapture = new Capture(DSoundHelper.DefaultVoiceCaptureDevice);

            // 2. To setup the wave format
            mywavform = new WaveFormat();

            // 3. To define the capture quality with waveformat
            mywavform.FormatTag = WaveFormatTag.Pcm;
            mywavform.Channels = 2;
            mywavform.SamplesPerSecond = 11025;
            mywavform.BitsPerSample = 8;

            mywavform.BlockAlign = (2*8)/8;

            mywavform.AverageBytesPerSecond = mywavform.BlockAlign * mywavform.SamplesPerSecond;
                        
            
            // 4. To Prediect the filesize


            notifysize = 512;

            

            // 5. Set the capturebuffersize
            NumberRecordNotifications = 8;
            mycapbuffsize = notifysize * NumberRecordNotifications;

            // 6. To Create the description of the capture Buffer
            CaptureBufferDescription mycapbuffdesc = new CaptureBufferDescription();
            mycapbuffdesc.BufferBytes = mycapbuffsize;
            mycapbuffdesc.WaveMapped = false;
            mycapbuffdesc.ControlEffects = false;
            mycapbuffdesc.Format = mywavform;

            // 7. Create capture buffer
            mycapbuff= new CaptureBuffer(mycapbuffdesc, mycap);

            // 9. To begin capture
            BeginCapturing();

            // 10. To set the capture flag
            mycapoffset = 0;
            //m_CaptureOffset = 0;
            mycapbuff.Start(true);

        }


        // To begin Capture
        private void BeginCapturing()
        {
            // 1. Set the thread for the job (which is located at WaitThread())
            if (mythread == null)
            {
                mythread = new Thread(new ThreadStart(WaitThread));
                m_NotificationEvent = new AutoResetEvent(false);
                m_Capturing = true;
                mythread.Start();
            }
            

            // 2. Setup the notification positions
            for (int i = 0; i < NumberRecordNotifications; i++)
            {
                m_PositionNotify[i].Offset = (notifysize * i) + notifysize - 1;
                m_PositionNotify[i].EventNotifyHandle = m_NotificationEvent.Handle;
            }

            m_Notify = new Notify(mycapbuff);
            m_Notify.SetNotificationPositions(m_PositionNotify, NumberRecordNotifications);
        }

        // WaitThread
        private void WaitThread()
        {
            while (m_Capturing)
            {
                m_NotificationEvent.WaitOne(Timeout.Infinite, true);
                WriteFileChunks();
            }
        }

        // Write Filecontent
        private void WriteFileChunks()
        {
            byte[] CaptureData = null;
            int ReadPos;
            int CapturePos;
            int LockSize;

            

            // If it is not capturing...
            if (!m_Capturing)
            {
                return;
            }

            // Get Capture Position and Read Position
            mycapbuff.GetCurrentPosition(out CapturePos, out ReadPos);
            LockSize = ReadPos - mycapoffset;
            if (LockSize < 0)
            {
                LockSize = LockSize + mycapbuffsize;
            }

            // Block align lock size so that we are always write on a boundary
            LockSize = LockSize - (LockSize % notifysize);

            if (LockSize == 0)
            {
                return;
            }

            // Read the capture buffer.
            CaptureData = (byte[])mycapbuff.Read(mycapoffset, typeof(byte), LockFlag.None, LockSize);


            switch (selAlgorithm)
            {
                case 0:
                    soundAlgorithms.byChange(CaptureData,ref vuL, ref vuR);
                    break;
                case 1:
                    soundAlgorithms.byMaxValue(CaptureData, ref vuL, ref vuR);
                    break;

                case 2:
                    soundAlgorithms.byChangeAvg(CaptureData, ref vuL, ref vuR);
                    break;

            }



            // Update the number of samples, in bytes, of the file so far.
            m_SampleCount = m_SampleCount + CaptureData.Length;

            // Move the capture offset along
            mycapoffset = mycapoffset + CaptureData.Length;
            mycapoffset = mycapoffset % mycapbuffsize; // Circular buffer

        }


        // Write the file tail
        private void WriteFileTrail()
        {
            m_Capturing = false;
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            selAlgorithm = lstAlgorithms.SelectedIndex;

            progressL.Value = vuL;
            progressR.Value = vuR;

            int b = 0;
            int c = 0;

                if(vuL > scr0.Value)
                    b |= 1;
                if (vuL > scr1.Value)
                    b |= 2;
                if (vuL > scr2.Value)
                    b |= 4;
                if (vuL > scr3.Value)
                    b |= 8;
                if (vuL > scr4.Value)
                    b |= 16;
                if (vuL > scr5.Value)
                    b |= 32;
                if (vuL > scr6.Value)
                    b |= 64;
                if (vuL > scr7.Value)
                    b |= 128;


                if (vuR > scr0.Value)
                    c |= 1;
                if (vuR > scr1.Value)
                    c |= 2;
                if (vuR > scr2.Value)
                    c |= 4;
                if (vuR > scr3.Value)
                    c |= 8;
                if (vuR > scr4.Value)
                    c |= 16;
                if (vuR > scr5.Value)
                    c |= 32;
                if (vuR > scr6.Value)
                    c |= 64;
                if (vuR > scr7.Value)
                    c |= 128;

            sendDevice(0, b);
            sendDevice(1, c);

            if(chckAuto.Checked)
                sendDevice(2, (b+c));
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            lstAlgorithms.SelectedIndex = 0;
            startcap();
        }

        private void formClose(object sender, FormClosedEventArgs e)
        {

            // Close USB device
            closeDevice();

            // 1. To stop the buffer
            mycapbuff.Stop();

            // 3. To Dispose the capture
            mycap.Dispose();

            // 4. Null the capture
            mycap = null;

            // 5. To dispose the buffer
            mycapbuff.Dispose();

            // 6. To Null the buffer
            mycapbuff = null;

            // 7. To write the File tail
            WriteFileTrail();

            // 8. To reset the flag
            m_Capturing = false;

            mythread.Abort();

            Application.Exit();
        }

        private void tmrReconnect_Tick(object sender, EventArgs e)
        {
            /*
            if (!isConnected)
                openDevice();
             */
        }

        private void resize(object sender, EventArgs e)
        {
            if (FormWindowState.Minimized == WindowState)
                Hide();
        }

        private void notifyDblClick(object sender, EventArgs e)
        {
            Show();
            WindowState = FormWindowState.Normal;
        }

        private void obnovitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Show();
            WindowState = FormWindowState.Normal;
        }


        private void trcPwm_Scroll(object sender, EventArgs e)
        {
            sendDevice(2, int.Parse(trcPwm.Value.ToString()));
        }

        private void button1_Click(object sender, EventArgs e)
        {
            closeDevice();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            openDevice();
        }






    }
}