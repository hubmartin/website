/* Name: main.c
 * Project: PowerSwitch based on AVR USB driver
 * Author: Christian Starkjohann
 * Creation Date: 2005-01-16
 * Tabsize: 4
 * Copyright: (c) 2005 by OBJECTIVE DEVELOPMENT Software GmbH
 * License: GNU GPL v2 (see License.txt) or proprietary (CommercialLicense.txt)
 * This Revision: $Id: main.c 452 2007-12-14 20:11:57Z cs $
 */

#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <avr/wdt.h>

#include "usbdrv.h"
#include "oddebug.h"
#include <util/delay.h>

char leftChannel;
char rightChannel;
char pwmValue = 50;

enum e {LEFT, RIGHT, PWM};

void setOutput(char left, char right)
{
    // Left Channel
		PORTC = left;
			
		PORTD = 0;
		if(left & 0b01000000)
			PORTD |= (1 << PIND3);
		if(left & 0b10000000)
			PORTD |= (1 << PIND4);

		// Right Channel
		PORTB = right;

    if(right & 0b01000000)
			PORTD |= (1 << PIND6);
		if(right & 0b10000000)
			PORTD |= (1 << PIND7);
}


USB_PUBLIC uchar usbFunctionSetup(uchar data[8])
{   

usbRequest_t    *rq = (void *)data;

		char command;
		char value;

		command = rq->bRequest;
		value = rq->wValue.bytes[0];
		
		switch(command)
		{
		 case LEFT:
		 	leftChannel = value;
		 	break;
		 		
		 case RIGHT:
		 	rightChannel = value;
		 	break;
		        		 
		 case PWM:
		 	pwmValue = value;
		 	break;
		 	
		
		}
        
    return 0;
}


int main(void)
{
uchar   i;
uchar	pwm;

    wdt_enable(WDTO_1S);
    odDebugInit();
    DDRD = 0;   
    PORTD = 0;
    PORTB = 0;          /* no pullups on USB pins */
/* We fake an USB disconnect by pulling D+ and D- to 0 during reset. This is
 * necessary if we had a watchdog reset or brownout reset to notify the host
 * that it should re-enumerate the device. Otherwise the host's and device's
 * concept of the device-ID would be out of sync.
 */
    //DDRB = ~USBMASK;    /* set all pins as outputs except USB */
    
    DDRB = 255;
    PORTB = 0;
    
    DDRC = 255;
    PORTC = 0;
    
    DDRD = (1 << PIND3) | (1 << PIND4)  | (1 << PIND6)| (1 << PIND7);
    //PORTD = (1 << PIND3) | (1 << PIND4) | (1 << PIND6)| (1 << PIND7);
    

    usbDeviceDisconnect();  /* enforce re-enumeration */
    i = 0;
    while(--i){         /* fake USB disconnect for > 500 ms */
        wdt_reset();
        _delay_ms(2);
    }
    usbDeviceConnect();
    usbInit();
    sei();
    
    pwm = 0;
    for(;;){    /* main event loop */
        wdt_reset();
        usbPoll();
        
        pwm++;
        if(pwm == 0)
        	setOutput(leftChannel, rightChannel);
				else if(pwm == pwmValue)
					setOutput(0, 0);
    }
    return 0;
}

