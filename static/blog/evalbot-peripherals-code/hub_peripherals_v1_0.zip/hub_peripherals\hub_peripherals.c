/*
 *
 * Peripherals example
 *
 * Martin Hubacek
 * http://www.martinhubacek.cz/
 * Date: 5. 7. 2011
 * Version: 1.0
 *
 * Start with EvalBot is little harder because
 * there are no ported examples of peripherals in StellarisWare.
 *
 * This code can help you to start, develop and learn with EvalBot.
 *
 * If you compile this example in CooCox CoIDE, you can try these functionality:
 *
 * - MicroSD card slot can be used to read data
 * - USB device connector is USB Mass Storage and you can access through it to the microSD card
 * - OLED display is initialized and shows some debug info about card and ethernet IP
 * - There's lwIP ethernet stack with DHCP client running on the EvalBot
 * - You can browse webpage thanks to the httpd. Pages are in folder /fs. make_filesystem.bat is for converting the folder to *.h file
 * - SSI (server side include) is enabled and there's on example in index.shtml
 * - You can find Evalbot on your network with Locator utility from Stellarisware /tools/bin/finder.exe
 * - You can flash firmware with LM Flash over ethernet
 *
 * All sourcecode is from StellarisWare. I ported examples from other part's and edited them so they could
 * be compiled in CoIDE and run on Evalbot. I had to change definition of the microSD card pins, set USB multiplexer
 * to the right connector and spent about a 2 more days to force the USB to enumerate, because Evalbot doesn't have
 * connected USB_ID pin.
 *
 * libdriver.a and libusb.a is includes. Only the LWIP is loading from the stellarisware directory.
 *
 * lwiplib.c from Stellarisware includes all the *.c files from /thirs_party/lwip directory. It's not the best solution
 * and I still wasn't be able to fix this include from Stellarisware, maybe in next versions of this example...
 *
 *
 */
#include "inc/hw_ints.h"
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "driverlib/debug.h"
#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"
#include "driverlib/interrupt.h"
#include "driverlib/rom.h"
#include "driverlib/systick.h"
#include "driverlib/usb.h"
#include "driverlib/udma.h"
#include "usblib/usblib.h"
#include "usblib/usb-ids.h"
#include "usblib/device/usbdevice.h"
#include "usblib/device/usbdmsc.h"

#include "usb_msc_structs.h"
#include "usbdsdcard.h"

#include "fatfs/src/diskio.h"

#include "drivers/display96x16x1.h"

#include "utils/uartstdio.h"
#include "utils/ustdlib.h"
#include <string.h>

#include "utils/swupdate.h"

// LWIP
#include "utils/locator.h"
#include "utils/lwiplib.h"

#include "httpd.h"

extern void lwIPEthernetIntHandler(void);

static char g_pcTwirl[4] = { '\\', '|', '/', '-' };
static unsigned long g_ulTwirlPos = 0;
static unsigned long g_ulLastIPAddr = 0;

//*****************************************************************************
//
// The parameters to control the USB mux on the LM3S3748 board.
//
//*****************************************************************************
#define USB_MUX_GPIO_PERIPH     SYSCTL_PERIPH_GPIOB
#define USB_MUX_GPIO_BASE       GPIO_PORTB_BASE
#define USB_MUX_GPIO_PIN        GPIO_PIN_0
#define USB_MUX_SEL_DEVICE      USB_MUX_GPIO_PIN
#define USB_MUX_SEL_HOST        0

//*****************************************************************************
//
// These defines are used to define the screen constraints to the application.
//
//*****************************************************************************
#define DISPLAY_BANNER_HEIGHT   14
#define DISPLAY_BANNER_BG       ClrDarkBlue
#define DISPLAY_BANNER_FG       ClrWhite

//*****************************************************************************
//
// The number of ticks to wait before falling back to the idle state.  Since
// the tick rate is 100Hz this is approximately 3 seconds.
//
//*****************************************************************************
#define USBMSC_ACTIVITY_TIMEOUT 300

#define SYSTICKHZ               100
#define SYSTICKMS               (1000 / SYSTICKHZ)


//
// SSI
//
#define INCLUDE_HTTPD_SSI

#define SSI_INDEX_LEDSTATE  0

static const char *g_pcConfigSSITags[] =
{
    "tag"        // SSI_INDEX_LEDSTATE
};

#define NUM_CONFIG_SSI_TAGS     (sizeof(g_pcConfigSSITags) / sizeof (char *))


//*****************************************************************************
//
// This enumeration holds the various states that the device can be in during
// normal operation.
//
//*****************************************************************************
volatile enum
{
    //
    // Unconfigured.
    //
    MSC_DEV_DISCONNECTED,

    //
    // Connected but not yet fully enumerated.
    //
    MSC_DEV_CONNECTED,

    //
    // Connected and fully enumerated but not currently handling a command.
    //
    MSC_DEV_IDLE,

    //
    // Currently reading the SD card.
    //
    MSC_DEV_READ,

    //
    // Currently writing the SD card.
    //
    MSC_DEV_WRITE,
}
g_eMSCState;

//*****************************************************************************
//
// The Flags that handle updates to the status area to avoid drawing when no
// updates are required..
//
//*****************************************************************************
#define FLAG_UPDATE_STATUS      1
static unsigned long g_ulFlags;
static unsigned long g_ulIdleTimeout;


static unsigned long g_ulTimer = 0;

static volatile tBoolean g_bFirmwareUpdate = false;

//******************************************************************************
//
// The DMA control structure table.
//
//******************************************************************************
#ifdef ewarm
#pragma data_alignment=1024
tDMAControlTable sDMAControlTable[64];
#elif defined(ccs)
#pragma DATA_ALIGN(sDMAControlTable, 1024)
tDMAControlTable sDMAControlTable[64];
#else
tDMAControlTable sDMAControlTable[64] __attribute__ ((aligned(1024)));
#endif

//*****************************************************************************
//
// Handles bulk driver notifications related to the receive channel (data from
// the USB host).
//
// \param pvCBData is the client-supplied callback pointer for this channel.
// \param ulEvent identifies the event we are being notified about.
// \param ulMsgValue is an event-specific value.
// \param pvMsgData is an event-specific pointer.
//
// This function is called by the bulk driver to notify us of any events
// related to operation of the receive data channel (the OUT channel carrying
// data from the USB host).
//
// \return The return value is event-specific.
//
//*****************************************************************************
unsigned long
RxHandler(void *pvCBData, unsigned long ulEvent,
               unsigned long ulMsgValue, void *pvMsgData)
{
    return(0);
}

//*****************************************************************************
//
// Handles bulk driver notifications related to the transmit channel (data to
// the USB host).
//
// \param pvCBData is the client-supplied callback pointer for this channel.
// \param ulEvent identifies the event we are being notified about.
// \param ulMsgValue is an event-specific value.
// \param pvMsgData is an event-specific pointer.
//
// This function is called by the bulk driver to notify us of any events
// related to operation of the transmit data channel (the IN channel carrying
// data to the USB host).
//
// \return The return value is event-specific.
//
//*****************************************************************************
unsigned long
TxHandler(void *pvCBData, unsigned long ulEvent, unsigned long ulMsgValue,
          void *pvMsgData)
{
    return(0);
}

// ssi
static int
SSIHandler(int iIndex, char *pcInsert, int iInsertLen)
{
    //unsigned long ulVal;

    //
    // Which SSI tag have we been passed?
    //
    switch(iIndex)
    {
        case SSI_INDEX_LEDSTATE:
        	usnprintf(pcInsert, iInsertLen, "LEDste");
            break;


        default:
            usnprintf(pcInsert, iInsertLen, "??");
            break;
    }

    //
    // Tell the server how many characters our insert string contains.
    //
    return(strlen(pcInsert));
}


//*****************************************************************************
//
// This function is the call back notification function provided to the USB
// library's mass storage class.
//
//*****************************************************************************
unsigned long
USBDMSCEventCallback(void *pvCBData, unsigned long ulEvent,
                     unsigned long ulMsgParam, void *pvMsgData)
{
    //
    // Reset the time out every time an event occurs.
    //
    g_ulIdleTimeout = USBMSC_ACTIVITY_TIMEOUT;

    switch(ulEvent)
    {
        //
        // Writing to the device.
        //
        case USBD_MSC_EVENT_WRITING:
        {
            //
            // Only update if this is a change.
            //
            if(g_eMSCState != MSC_DEV_WRITE)
            {
                //
                // Go to the write state.
                //
                g_eMSCState = MSC_DEV_WRITE;

                //
                // Cause the main loop to update the screen.
                //
                g_ulFlags |= FLAG_UPDATE_STATUS;
            }

            break;
        }

        //
        // Reading from the device.
        //
        case USBD_MSC_EVENT_READING:
        {
            //
            // Only update if this is a change.
            //
            if(g_eMSCState != MSC_DEV_READ)
            {
                //
                // Go to the read state.
                //
                g_eMSCState = MSC_DEV_READ;

                //
                // Cause the main loop to update the screen.
                //
                g_ulFlags |= FLAG_UPDATE_STATUS;
            }

            break;
        }
        case USBD_MSC_EVENT_IDLE:
        default:
        {
            break;
        }
    }

    return(0);
}

//*****************************************************************************
//
// This is the handler for this SysTick interrupt.  FatFs requires a timer tick
// every 10 ms for internal timing purposes.
//
//*****************************************************************************

void
lwIPHostTimerHandler(void)
{
	   unsigned long ulIPAddress;
	   char temp[20];
	    //
	    // Get the local IP address.
	    //
	    ulIPAddress = lwIPLocalIPAddrGet();

	    //
	    // See if an IP address has been assigned.
	    //
	    if(ulIPAddress == 0)
	    {
	        //
	        // Draw a spinning line to indicate that the IP address is being
	        // discoverd.
	        //
	        UARTprintf("\b%c", g_pcTwirl[g_ulTwirlPos]);

	        //
	        // Update the index into the twirl.
	        //
	        g_ulTwirlPos = (g_ulTwirlPos + 1) & 3;
	    }

	    //
	    // Check if IP address has changed, and display if it has.
	    //
	    else if(ulIPAddress != g_ulLastIPAddr)
	    {
	        //
	        // Display the new IP address.
	        //
	        UARTprintf("\rIP: %d.%d.%d.%d       \n", ulIPAddress & 0xff,
	                   (ulIPAddress >> 8) & 0xff, (ulIPAddress >> 16) & 0xff,
	                   (ulIPAddress >> 24) & 0xff);

	        usprintf(temp, "%d.%d.%d.%d", ulIPAddress & 0xff,
	                   (ulIPAddress >> 8) & 0xff, (ulIPAddress >> 16) & 0xff,
	                   (ulIPAddress >> 24) & 0xff);
	        Display96x16x1StringDrawCentered(temp, 8, true);

	        //
	        // Save the new IP address.
	        //
	        g_ulLastIPAddr = ulIPAddress;

	        //
	        // Display the new network mask.
	        //
	        ulIPAddress = lwIPLocalNetMaskGet();
	        UARTprintf("Netmask: %d.%d.%d.%d\n", ulIPAddress & 0xff,
	                   (ulIPAddress >> 8) & 0xff, (ulIPAddress >> 16) & 0xff,
	                   (ulIPAddress >> 24) & 0xff);

	        //
	        // Display the new gateway address.
	        //
	        ulIPAddress = lwIPLocalGWAddrGet();
	        UARTprintf("Gateway: %d.%d.%d.%d\n", ulIPAddress & 0xff,
	                   (ulIPAddress >> 8) & 0xff, (ulIPAddress >> 16) & 0xff,
	                   (ulIPAddress >> 24) & 0xff);
	    }
}

void
SysTick_Handler(void)
{
    //
    // Call the FatFs tick timer.
    //
    disk_timerproc();

    lwIPTimer(SYSTICKMS);

    if(g_ulIdleTimeout != 0)
    {
        g_ulIdleTimeout--;
    }

    // Half of second
    if(g_ulTimer++ % 50 == 0)
    {

    }
}

void
USB0_IRQHandler(void)
{
	USB0DeviceIntHandler();
}

void
Ethernet_IRQHandler(void)
{
	lwIPEthernetIntHandler();
}

void SoftwareUpdateRequestCallback(void)
{
    g_bFirmwareUpdate = true;
}

//*****************************************************************************
//
// This is the main loop that runs the application.
//
//*****************************************************************************
int
main(void)
{
    unsigned long ulUser0, ulUser1;
    unsigned char pucMACArray[8];
 
    //
    // Set the clocking to run directly from the crystal.
    //
    ROM_SysCtlClockSet(SYSCTL_SYSDIV_4 | SYSCTL_USE_PLL | SYSCTL_OSC_MAIN | SYSCTL_XTAL_16MHZ);
    
    // Turn on LED
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);
	GPIOPinTypeGPIOOutput(GPIO_PORTF_BASE, GPIO_PIN_4);
	GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_4, GPIO_PIN_4);

    //
    // Enable the USB mux GPIO.
    //
    ROM_SysCtlPeripheralEnable(USB_MUX_GPIO_PERIPH);
    ROM_GPIOPinTypeGPIOOutput(USB_MUX_GPIO_BASE, USB_MUX_GPIO_PIN);
    ROM_GPIOPinWrite(USB_MUX_GPIO_BASE, USB_MUX_GPIO_PIN, USB_MUX_SEL_DEVICE);
    
    //
    // Set GPIO A0 and A1 as UART pins.
    //
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);
    GPIOPinConfigure(GPIO_PA0_U0RX);
    GPIOPinConfigure(GPIO_PA1_U0TX);
    ROM_GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);

    UARTStdioInitExpClk(0, 115200);
    UARTprintf("Hello\n");


    // Display
    Display96x16x1Init(true);
    Display96x16x1StringDrawCentered("Connect USB Host", 0, true);

    //
    // Enable and Reset the Ethernet Controller.
    //
    ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_ETH);
    ROM_SysCtlPeripheralReset(SYSCTL_PERIPH_ETH);

    //
    // Enable Port F for Ethernet LEDs.
    //
    ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);
    GPIOPinConfigure(GPIO_PF2_LED1);
    GPIOPinConfigure(GPIO_PF3_LED0);
    GPIOPinTypeEthernetLED(GPIO_PORTF_BASE, GPIO_PIN_2 | GPIO_PIN_3);

    //
    // Configure SysTick for a 100Hz interrupt.  The FatFs driver wants a 10 ms
    // tick.
    //
    ROM_SysTickPeriodSet(ROM_SysCtlClockGet() / SYSTICKHZ);
    ROM_SysTickEnable();
    ROM_SysTickIntEnable();

    //
    // Configure and enable uDMA
    //
    ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_UDMA);
    SysCtlDelay(10);
    uDMAControlBaseSet(&sDMAControlTable[0]);
    uDMAEnable();


    //
    // Read the MAC address from the user registers.
    //
    ROM_FlashUserGet(&ulUser0, &ulUser1);
    if((ulUser0 == 0xffffffff) || (ulUser1 == 0xffffffff))
    {
        //
        // We should never get here.  This is an error if the MAC address has
        // not been programmed into the device.  Exit the program.
        //
        UARTprintf("MAC Address Not Programmed!\n");
        while(1)
        {
        }
    }

    //
    // Convert the 24/24 split MAC address from NV ram into a 32/16 split MAC
    // address needed to program the hardware registers, then program the MAC
    // address into the Ethernet Controller registers.
    //
    pucMACArray[0] = ((ulUser0 >>  0) & 0xff);
    pucMACArray[1] = ((ulUser0 >>  8) & 0xff);
    pucMACArray[2] = ((ulUser0 >> 16) & 0xff);
    pucMACArray[3] = ((ulUser1 >>  0) & 0xff);
    pucMACArray[4] = ((ulUser1 >>  8) & 0xff);
    pucMACArray[5] = ((ulUser1 >> 16) & 0xff);

    //
    // Initialze the lwIP library, using DHCP.
    //
    lwIPInit(pucMACArray, 0, 0, 0, IPADDR_USE_DHCP);

    //
    // Setup the device locator service.
    //
    LocatorInit();
    LocatorMACAddrSet(pucMACArray);
    LocatorAppTitleSet("HuB's CooCox test");

    http_set_ssi_handler(SSIHandler, g_pcConfigSSITags, NUM_CONFIG_SSI_TAGS);

    // swUpdate
    SoftwareUpdateInit(SoftwareUpdateRequestCallback);

    //
    // Indicate that DHCP has started.
    //
    UARTprintf("Waiting for IP... ");

    //
    // Initialize a sample httpd server.
    //
    httpd_init();




    //
    // Pass our device information to the USB library and place the device
    // on the bus.
    //
    USBDMSCInit(0, (tUSBDMSCDevice *)&g_sMSCDevice);
    
    USBDevMode(USB0_BASE);

    //
    // Drop into the main loop.
    //
    while(!g_bFirmwareUpdate)
    {
        switch(g_eMSCState)
        {
            case MSC_DEV_READ:
            {
                //
                // Update the screen if necessary.
                //
                if(g_ulFlags & FLAG_UPDATE_STATUS)
                {
                	Display96x16x1StringDrawCentered("Reading", 0, true);
                    g_ulFlags &= ~FLAG_UPDATE_STATUS;
                }

                //
                // If there is no activity then return to the idle state.
                //
                if(g_ulIdleTimeout == 0)
                {
                	Display96x16x1StringDrawCentered("Idle", 0, true);
                    g_eMSCState = MSC_DEV_IDLE;
                }

                break;
            }
            case MSC_DEV_WRITE:
            {
                //
                // Update the screen if necessary.
                //
                if(g_ulFlags & FLAG_UPDATE_STATUS)
                {
                	Display96x16x1StringDrawCentered("Writing", 0, true);
                    g_ulFlags &= ~FLAG_UPDATE_STATUS;
                }

                //
                // If there is no activity then return to the idle state.
                //
                if(g_ulIdleTimeout == 0)
                {
                	Display96x16x1StringDrawCentered("Idle", 0, true);
                    g_eMSCState = MSC_DEV_IDLE;
                }
                break;
            }
            case MSC_DEV_IDLE:
            default:
            {
                break;
            }
        }
    }

    Display96x16x1StringDrawCentered("SW Update!", 0, true);

    SoftwareUpdateBegin();

    while(1);
}

//*****************************************************************************
//
// The error routine that is called if the driver library encounters an error.
//
//*****************************************************************************
#ifdef DEBUG
void
__error__(char *pcFilename, unsigned long ulLine)
{
}
#endif

