

#ifndef __JOYSTICK_H__
#define __JOYSTICK_H__





void adcInit();
char adcGetDir();

void joystickDisable();
void joystickEnable();

#endif
