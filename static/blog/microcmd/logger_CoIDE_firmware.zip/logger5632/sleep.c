
#include "inc/hw_types.h"
#include "inc/hw_memmap.h"
#include "inc/hw_gpio.h"
#include "driverlib/cpu.h"
#include "driverlib/gpio.h"
#include "driverlib/debug.h"
#include "driverlib/sysctl.h"
#include "driverlib/adc.h"
#include "driverlib/systick.h"
#include "driverlib/interrupt.h"

#include "driverlib/hibernate.h"

#include "sleep.h"

unsigned long ulHibernateCount = 0;

void sleepInit()
{
	SysCtlPeripheralEnable(SYSCTL_PERIPH_HIBERNATE);

	HibernateEnableExpClk(SysCtlClockGet());
	HibernateClockSelect(HIBERNATE_CLOCK_SEL_RAW);

	HibernateRTCEnable();
}



void doSleep()
{


    HibernateRTCSet(0);
    HibernateRTCEnable();
    HibernateRTCMatch0Set(5);
    HibernateRTCMatch1Set(5);

    //
    // Set wake condition on pin or RTC match.  Board will wake when 5 seconds
    // elapses, or when the button is pressed.
    //
    HibernateWakeSet(HIBERNATE_WAKE_PIN | HIBERNATE_WAKE_RTC);

    ulHibernateCount++;
        HibernateDataSet(&ulHibernateCount, 1);

    //
    // Request hibernation.
    //
    HibernateRequest();
}

