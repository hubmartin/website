

#include "inc/hw_types.h"
#include "inc/hw_memmap.h"
#include "inc/hw_gpio.h"
#include "driverlib/cpu.h"
#include "driverlib/gpio.h"
#include "driverlib/adc.h"
#include "driverlib/systick.h"
#include "driverlib/interrupt.h"
#include "driverlib/sysctl.h"

#include "joystick.h"

int joystickEnabled = 0;


void joystickDisable()
{
	joystickEnabled = 0;
}

void joystickEnable()
{
	joystickEnabled = 1;
}


void ADCSeq1_IRQHandler()
{

}


void adcInit()
{

		//ADC INIT
	SysCtlPeripheralEnable(SYSCTL_PERIPH_ADC0);
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOD);
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOE);

	GPIOPinTypeADC(GPIO_PORTD_BASE, GPIO_PIN_2 | GPIO_PIN_3 );
	GPIOPinTypeADC(GPIO_PORTE_BASE, GPIO_PIN_3 );

	SysCtlADCSpeedSet(SYSCTL_ADCSPEED_1MSPS);


	ADCSequenceDisable(ADC0_BASE, 1);

	ADCSequenceConfigure(ADC0_BASE, 1, ADC_TRIGGER_PROCESSOR, 0);

	ADCSequenceStepConfigure(ADC_BASE, 1, 0, ADC_CTL_CH0);
	ADCSequenceStepConfigure(ADC_BASE, 1, 1, ADC_CTL_TS);
	ADCSequenceStepConfigure(ADC_BASE, 1, 2, ADC_CTL_CH4);
	ADCSequenceStepConfigure(ADC0_BASE, 1, 3, ADC_CTL_CH5| ADC_CTL_IE | ADC_CTL_END);

	ADCHardwareOversampleConfigure(ADC0_BASE, 1);

	// zp�sobuje tuhnut�
	ADCSequenceEnable(ADC0_BASE, 1);

	ADCIntClear(ADC0_BASE, 1);

	joystickEnabled = 1;

}


char adcGetDir()
{
	int x,y;
	unsigned long ulSeq1DataBuffer[4];

	if(!joystickEnabled)
		return 0;

	ADCProcessorTrigger(ADC0_BASE, 1);

	while(!ADCIntStatus(ADC0_BASE, 1, false))
	        {
	        }

	ADCIntClear(ADC0_BASE, 1);

	ADCSequenceDataGet(ADC0_BASE, 1, ulSeq1DataBuffer);
	x = 1000 - ulSeq1DataBuffer[2];
	y =  ulSeq1DataBuffer[3];

	if(x > 700)
		return 'R';
	else if(x < 300)
		return 'L';
	else if(y < 400)
		return 'U';
	else if(y > 800)
		return 'D';
	else
		return 0;

}
