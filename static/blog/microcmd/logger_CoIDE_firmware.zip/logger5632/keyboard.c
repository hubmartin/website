#include "inc/hw_types.h"
#include "inc/hw_memmap.h"
#include "inc/hw_gpio.h"
#include "driverlib/cpu.h"
#include "driverlib/gpio.h"
#include "driverlib/debug.h"
#include "driverlib/sysctl.h"
#include "driverlib/adc.h"
#include "driverlib/systick.h"
#include "driverlib/interrupt.h"

#include "keyboard.h"

#include "joystick.h"


volatile unsigned char keyPress = 0;
unsigned int longPress = 0;



void keyboardInit() {

	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOC);
	GPIOPinTypeGPIOInput(GPIO_PORTC_BASE,  GPIO_PIN_5 | GPIO_PIN_6);
	GPIOPadConfigSet(GPIO_PORTC_BASE, GPIO_PIN_5 | GPIO_PIN_6, GPIO_STRENGTH_2MA,GPIO_PIN_TYPE_STD_WPU);

}


int getEvent()
{
	int event = keyPress;
	keyPress = 0;

	return event;
}

int keyboardGet(void)
{
	   static unsigned char key = 0;

	   key = adcGetDir();

	   if(key==0)
	   {
		   unsigned int pinRead = GPIOPinRead(GPIO_PORTC_BASE, GPIO_PIN_5 | GPIO_PIN_6);

			if((pinRead & GPIO_PIN_5) == 0)
				key = BTN_A;

			if((pinRead & GPIO_PIN_6) == 0)
				key = BTN_B;
	   }

	   if(key==0)
		   key = K_KLAV_NIC;


		   return key;
}

void keyboardHandler() {

   static unsigned char lastKey = 0x0F;
   static unsigned char debounce = 0;
   static unsigned char key;
   
   key = keyboardGet();

  
  if(key == lastKey && key != K_KLAV_NIC){
  	
  	if(debounce < 200)
  		debounce++;
  	if(key != BTN_LEFT && key != BTN_RIGHT && debounce > 50) {
  		longPress++;
	  	if(longPress == 12) {
	  		longPress = 0;	
	  		keyPress = key;
	  	}
  	}
  	
  }	else {
  	debounce = 0;
  }
  
  if(debounce == 3)
  	keyPress = key;
 
  lastKey = key; 


}


	
	
