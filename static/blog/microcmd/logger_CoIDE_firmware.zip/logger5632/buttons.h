

#ifndef __BUTTONS_H__
#define __BUTTONS_H__


void btnInit();
{

}

#endif
