

#ifndef __MENU_H__
#define __MENU_H__

#define int8_t int16_t
#define uint8_t unsigned char

#define int16_t short

       
#define LANGUAGE_CZECH 0
#define LANGUAGE_ENGLISH 1

extern char actualLanguage;

// Makro usnad�uj�c� zobrazen� �et�zce podle navolen�ho jazyka
#define lcd_putsLang(name) lcd_puts(name[actualLanguage])

void displayMainMenu(void);
int showMenu(char *array[]);

uint8_t menuEditTemp(const char* str, int* temp, int increment);
int8_t menuEditTime(char *str, uint8_t* pHours, uint8_t* pMinutes);
int8_t menuMsgBox(const char *str);
uint8_t menuEditNumber(const char *str, int16_t *val, const char *unit, uint8_t inc, int16_t valMin, int16_t valMax);

#define MENU_LINES 5

extern volatile int menuPreselect;

#endif
