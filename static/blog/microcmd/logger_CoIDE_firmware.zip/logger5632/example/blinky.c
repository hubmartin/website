//*****************************************************************************
//
// blinky.c - Simple application that blinks the LED.
//
//*****************************************************************************
#include "inc/hw_types.h"
#include "inc/hw_memmap.h"
#include "inc/hw_gpio.h"
#include "driverlib/gpio.h"
#include "driverlib/debug.h"
#include "driverlib/sysctl.h"

void blinky()
{
	volatile unsigned long ulLoop;

    //
    // Enable the GPIO port that is used for the on-board LED.
    //
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOB);

    //
    // Enable the GPIO pin for the LED (PF3).  Set the direction as output, and
    // enable the GPIO pin for digital function.
    //
	GPIOPinTypeGPIOOutput(GPIO_PORTB_BASE, GPIO_PIN_2);

   	// Loop forever.
	while(1)
    {
        //        
		// Delay some time		
        //
        for(ulLoop = 0; ulLoop < 200000; ulLoop++);
        //
        // Output high level
        //
        GPIOPinWrite(GPIO_PORTB_BASE, GPIO_PIN_2, ~GPIO_PIN_2);
        //
        // Delay some time
        //
        for(ulLoop = 0; ulLoop < 200000; ulLoop++);
        //
        // Output low level
        //
        GPIOPinWrite(GPIO_PORTB_BASE, GPIO_PIN_2, GPIO_PIN_2);
    }
}
