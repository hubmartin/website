

#ifndef __SLEEP_H__
#define __SLEEP_H__



void sleepInit();
void doSleep();

#endif
