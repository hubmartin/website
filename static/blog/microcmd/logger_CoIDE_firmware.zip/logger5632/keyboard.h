

#ifndef _KEYBOARD_H
#define _KEYBOARD_H


#define BTN_UP 'U'
#define BTN_DOWN 'D'
#define BTN_LEFT 'L'
#define BTN_RIGHT 'R'
#define BTN_ENTER 'E'

#define BTN_A	'A'
#define BTN_B	'B'

#define BTN_PORT	PORTC
#define BTN_PIN		PINC
#define BTN_DDR		DDRC



#define PIN_BTN_DOWN	_BV(PD7)
#define PORT_BTN_DOWN	PORTD
#define READ_BTN_DOWN	PIND

#define PIN_BTN_UP 		_BV(PB7)
#define PORT_BTN_UP		PORTB
#define READ_BTN_UP		PINB

#define PIN_BTN_LEFT 	_BV(PC4)
#define PORT_BTN_LEFT	PORTC
#define READ_BTN_LEFT	PINC

#define PIN_BTN_RIGHT 	_BV(PD3)
#define PORT_BTN_RIGHT	PORTD
#define READ_BTN_RIGHT	PIND

#define PIN_BTN_COMMON _BV(PC1)


#define K_KLAV_NIC 'X'

volatile extern unsigned char keyPress;
extern unsigned int longPress;



void keyboardInit(void);
void keyboardHandler(void);
int keyboardGet(void);

int getEvent();

#endif
