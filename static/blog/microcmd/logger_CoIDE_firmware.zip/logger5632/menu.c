
#include "lcd.h"

#define  lcd_clrscr LcdClear
#define lcd_gotoxy gotoXY
#define lcd_puts LcdString
#define lcd_putc LcdCharacter



#include "menu.h"
#include "keyboard.h"


char actualLanguage = LANGUAGE_CZECH;

int menuSelect;

volatile int menuPreselect = -1;




int showMenu(char *array[]) {


	unsigned char infiniteLoop = 1;
	unsigned char menuItem = 0;
  unsigned char lastMenuItem = 255;

  unsigned char cursorTopPos = 0;
  unsigned char menuTopPos = 0;
  char **iList = array;

  unsigned char i;
  


  //
  // Get number of items in menu, search for the first NULL
  //
  int len = -1;
  for (; *iList != 0; ++iList)
  {
      len++;
  }
   /*
	// TODO: bug preselect p�i 2 polo�k�ch v menu
	if(menuPreselect != -1)
	{
   		menuItem = menuPreselect;
		if(len > MENU_LINES)
			menuTopPos = menuPreselect;
		else
			menuTopPos = 0;

		if(menuTopPos > len - MENU_LINES && len > 3)
		{
			menuTopPos = len - MENU_LINES;
		}
		cursorTopPos = menuItem - menuTopPos;
	}*/
    
  //
  // Switch pointer to actual language
  //   
  //array += actualLanguage * (len + 2);      
        
        
	
	while(infiniteLoop) {

		SysCtlSleep();

	if(keyPress) {
		
      //
      // Down
      //
		if(keyPress == BTN_DOWN)
      {
	  	if(menuItem != len-1)
		{
		menuItem++;
                   /*
        if(cursorTopPos < 2)
          cursorTopPos++;
        else
          menuTopPos++;*/

        if(cursorTopPos >= MENU_LINES-1)
          menuTopPos++;
        else
          cursorTopPos++;

		} else {
			menuItem = 0;
			cursorTopPos = 0;
			menuTopPos = 0;
		}
      }
      
      //
      // Up
      //
	  if(keyPress == BTN_UP)
      {
	  	if(menuItem != 0)
		{
		menuItem--;
                                
        if(cursorTopPos > 0)
          cursorTopPos--;
        else
          menuTopPos--;
		  } else {
		  	menuItem = len-1;
			
			if(len <= MENU_LINES)
			{
				menuTopPos = 0;
			} else {
				menuTopPos = menuItem;
			}
			if(menuTopPos > len - MENU_LINES && len >= MENU_LINES)
			{
				menuTopPos = len - MENU_LINES;
			}
			
			cursorTopPos = menuItem - menuTopPos;
		  }
      }
                        
                       
      //
      // Enter
      //                  
		if(keyPress == BTN_ENTER || keyPress == BTN_RIGHT)
      {
        keyPress = 0;  
		menuPreselect = -1;
				return menuItem;
      }
      
      
      //  
      // Left - back
      //                  
      if(keyPress == BTN_LEFT)
      {
        keyPress = 0;  
		menuPreselect = -1;
				return -1;
      }
      
                        
			keyPress = 0; 
    
                        
		} // if(keyPress)
                
    //
    // If menu item changed -> refresh screen
    //            
    if(lastMenuItem != menuItem)
    {
      lcdClearBuffer();
      //lcdBufferString("=======",0,0);

      lcdBufferString(array[0],1,0);
	  /*
	  lcd_number(menuItem);
	  lcd_putc(';');
	  lcd_number(menuTopPos);
      lcd_putc(';');
	  lcd_number(cursorTopPos);*/
      
      i = 0;
      while((i + menuTopPos) < len &&   i < MENU_LINES)
	  //while((i + menuTopPos) < (len & i) < 3)
      {
        if(menuItem == i + menuTopPos)
        {
          lcdBufferString(">", 0, (i+1)*8);
        }
        lcdBufferString(array[menuTopPos + i + 1], 2*6, (i+1)*8);
        i++;
      }

	  //lcd_gotoxy(0, 1);
	  //lcd_puts(array[menuItem + 1]);
      lcdDrawBuffer();
      
      lastMenuItem = menuItem;
    }

			
	}   
	
	return 0;
}



uint8_t menuEditTemp(const char* str, int* temp, int increment)
{
	int editTemp = *temp;

	for(;;)
	{

	lcd_clrscr();
	lcd_puts(str);

	lcd_gotoxy(2,1);
	lcd_put_tempv(editTemp, 1);

	while(keyPress == 0);

	switch(keyPress)
	{

		case BTN_UP:
			keyPress = 0;
			editTemp += increment;
			break;

		case BTN_DOWN:
			keyPress = 0;
			editTemp -= increment;
			break;

		case BTN_RIGHT:
			keyPress = 0;
			*temp = editTemp;
			return 1;
			break;

		case BTN_LEFT:
			keyPress = 0;
			return 0;
			break;

	}
	}

}



int8_t menuEditTime(char *str, uint8_t* pHours, uint8_t* pMinutes)
{
	int8_t hours, minutes, deciMinutes;

	unsigned char editPos = 0;
	unsigned char editGoto[] = {1, 3, 4};

	unsigned char relX = 7, relY = 2;

	hours = *pHours;
	minutes = *pMinutes % 10;
	deciMinutes = *pMinutes / 10;


	for(;;)
	{
		lcd_clrscr();
		lcd_puts(str);
		lcd_gotoxy(relX, relY);
		lcd_number2(hours);
		lcd_putc(':');
		lcd_number(deciMinutes);
		lcd_number(minutes);

		lcd_gotoxy(editGoto[editPos] + relX, relY);
		
		//lcd_command(LCD_DISP_ON_CURSOR);

		while(keyPress == 0);

		//lcd_command(LCD_DISP_ON);

		switch(keyPress)
		{
			case BTN_LEFT:
				keyPress = 0;
				if(editPos == 0)
					return 0;
				editPos--;
				break;

			case BTN_RIGHT:
				keyPress = 0;
				if(editPos == 2)
				{
					*pHours = hours;
					*pMinutes = deciMinutes*10 + minutes;
					return 1;
				}
				editPos++;
				break;

			case BTN_UP:
				keyPress = 0;
				if(editPos == 0)
				{
					hours++;
					if(hours > 23)
						hours = 0;
				}
				if(editPos == 1)
				{
					deciMinutes++;
					if(deciMinutes > 5)
						deciMinutes = 0;
				}
				if(editPos == 2)
				{
					minutes++;
					if(minutes > 9)
						minutes = 0;
				}
				break;

			case BTN_DOWN:
				keyPress = 0;
				if(editPos == 0)
				{
					hours--;
					if(hours < 0)
						hours = 23;
				}
				if(editPos == 1)
				{
					deciMinutes--;
					if(deciMinutes < 0)
						deciMinutes = 5;
				}
				if(editPos == 2)
				{
					minutes--;
					if(minutes < 0)
						minutes = 9;
				}
				break;

			default:
				keyPress = 0;
				break;

		}

	}


}



int8_t menuMsgBox(const char *str)
{
	lcd_clrscr();

	lcd_puts(str);

	while(keyPress == 0);
	keyPress = 0;

	return 1;

}


uint8_t menuEditNumber(const char *str, int16_t *val, const char *unit, uint8_t inc, int16_t valMin, int16_t valMax)
{
	int16_t actVal = *val;

	for(;;)
	{
		lcd_clrscr();
		lcd_puts(str);
		lcd_gotoxy(5,2);
		lcd_number(actVal);
		lcd_puts(unit);

		while(keyPress == 0);

		switch(keyPress)
		{
			case BTN_LEFT:
				keyPress = 0;
				return 0;
				break;
			
			case BTN_RIGHT:
				keyPress = 0;
				*val = actVal;
				return 1;
				break;

			case BTN_UP:
				keyPress = 0;
				if(actVal + inc <= valMax)
					actVal += inc;
				break;


			case BTN_DOWN:
				keyPress = 0;
				if(actVal - inc >= valMin)
					actVal -= inc;
				break;

		}

	}


}
