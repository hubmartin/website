


#include "inc/hw_types.h"
#include "inc/hw_memmap.h"
#include "inc/hw_gpio.h"
#include "driverlib/cpu.h"
#include "driverlib/gpio.h"
#include "driverlib/debug.h"
#include "driverlib/sysctl.h"
#include "driverlib/adc.h"
#include "driverlib/systick.h"
#include "driverlib/interrupt.h"

//#include "driverlib/hibernate.h"

#include "lcd.h"
#include "joystick.h"
#include "sleep.h"
#include "keyboard.h"

#include "menu.h"
#include "app.h"

#include "fatfs/ff.h"

#define min(x,y) ((x < y) ? x : y)
#define max(x,y) ((x > y) ? x : y)

void disk_timerproc (void);

void blinky();

long map(long x, long in_min, long in_max, long out_min, long out_max)
{
	long ret = (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;

	if(x < in_min)
		return out_min;

	if(x > in_max)
		return out_max;

  	return ret;
}

unsigned int
strlen(const char *str)
{
        const char *s;

        for (s = str; *s; ++s)
                ;
        return (s - str);
}



unsigned char ledState = 0;
volatile unsigned long msTick = 0;


void SysTick_Handler()
{

	msTick++;

	if((msTick % 10) == 0)
	{
		keyboardHandler();
		disk_timerproc();
	}

	if((msTick % 1000) == 0)
	{
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOB);
    GPIOPinTypeGPIOOutput(GPIO_PORTB_BASE, GPIO_PIN_2);

    if(ledState)
    	GPIOPinWrite(GPIO_PORTB_BASE, GPIO_PIN_2, GPIO_PIN_2);
    else
    	GPIOPinWrite(GPIO_PORTB_BASE, GPIO_PIN_2, 0);

    ledState = !ledState;

	}

}

void delay(unsigned long d)
{
	unsigned long timeToLeave = msTick + d;
	while(msTick < timeToLeave);
}

int main(void)
{




	   SysCtlPeripheralClockGating(true);

	   // Deep sleep disable
	    SysCtlPeripheralDeepSleepDisable(SYSCTL_PERIPH_ADC);

	    SysCtlPeripheralDeepSleepDisable(SYSCTL_PERIPH_COMP0);
	    SysCtlPeripheralDeepSleepDisable(SYSCTL_PERIPH_COMP1);
	    SysCtlPeripheralDeepSleepDisable(SYSCTL_PERIPH_COMP2);

	    SysCtlPeripheralDeepSleepDisable(SYSCTL_PERIPH_ETH);

	    SysCtlPeripheralDeepSleepDisable(SYSCTL_PERIPH_GPIOA);
	    SysCtlPeripheralDeepSleepDisable(SYSCTL_PERIPH_GPIOB);
	    SysCtlPeripheralDeepSleepDisable(SYSCTL_PERIPH_GPIOC);
	    SysCtlPeripheralDeepSleepDisable(SYSCTL_PERIPH_GPIOD);
	    SysCtlPeripheralDeepSleepDisable(SYSCTL_PERIPH_GPIOE);
	    SysCtlPeripheralDeepSleepDisable(SYSCTL_PERIPH_GPIOF);
	    SysCtlPeripheralDeepSleepDisable(SYSCTL_PERIPH_GPIOG);
	    SysCtlPeripheralDeepSleepDisable(SYSCTL_PERIPH_GPIOH);

	    SysCtlPeripheralDeepSleepDisable(SYSCTL_PERIPH_HIBERNATE);
	    SysCtlPeripheralDeepSleepDisable(SYSCTL_PERIPH_I2C0);
	    SysCtlPeripheralDeepSleepDisable(SYSCTL_PERIPH_I2C1);
	    SysCtlPeripheralDeepSleepDisable(SYSCTL_PERIPH_PWM);
	    SysCtlPeripheralDeepSleepDisable(SYSCTL_PERIPH_QEI0);
	    SysCtlPeripheralDeepSleepDisable(SYSCTL_PERIPH_QEI1);
	    SysCtlPeripheralDeepSleepDisable(SYSCTL_PERIPH_SSI0);
	    SysCtlPeripheralDeepSleepDisable(SYSCTL_PERIPH_SSI1);

	    SysCtlPeripheralDeepSleepDisable(SYSCTL_PERIPH_TIMER0);
	    SysCtlPeripheralDeepSleepDisable(SYSCTL_PERIPH_TIMER1);
	    SysCtlPeripheralDeepSleepDisable(SYSCTL_PERIPH_TIMER2);
	    SysCtlPeripheralDeepSleepDisable(SYSCTL_PERIPH_TIMER3);

	    SysCtlPeripheralDeepSleepDisable(SYSCTL_PERIPH_UART0);
	    SysCtlPeripheralDeepSleepDisable(SYSCTL_PERIPH_UART1);
	    SysCtlPeripheralDeepSleepDisable(SYSCTL_PERIPH_UART2);

	    SysCtlPeripheralDeepSleepDisable(SYSCTL_PERIPH_WDOG);
	    SysCtlPeripheralDeepSleepDisable(SYSCTL_PERIPH_UDMA);

	    /*
	    SysCtlPeripheralEnable(SYSCTL_PERIPH_USB0);
	    SysCtlPeripheralReset(SYSCTL_PERIPH_USB0);
	    SysCtlPeripheralDeepSleepDisable(SYSCTL_PERIPH_USB0);
	    SysCtlPeripheralDisable(SYSCTL_PERIPH_USB0);*/



	    // Sleep disable
	    SysCtlPeripheralSleepDisable(SYSCTL_PERIPH_ADC);

	    SysCtlPeripheralSleepDisable(SYSCTL_PERIPH_COMP0);
	    SysCtlPeripheralSleepDisable(SYSCTL_PERIPH_COMP1);
	    SysCtlPeripheralSleepDisable(SYSCTL_PERIPH_COMP2);

	    SysCtlPeripheralSleepDisable(SYSCTL_PERIPH_ETH);

	    SysCtlPeripheralSleepEnable(SYSCTL_PERIPH_GPIOA);
	    SysCtlPeripheralSleepEnable(SYSCTL_PERIPH_GPIOB);
	    SysCtlPeripheralSleepEnable(SYSCTL_PERIPH_GPIOC);
	    SysCtlPeripheralSleepEnable(SYSCTL_PERIPH_GPIOD);
	    SysCtlPeripheralSleepEnable(SYSCTL_PERIPH_GPIOE);
	    SysCtlPeripheralSleepEnable(SYSCTL_PERIPH_GPIOF);
	    SysCtlPeripheralSleepEnable(SYSCTL_PERIPH_GPIOG);
	    SysCtlPeripheralSleepEnable(SYSCTL_PERIPH_GPIOH);

	    SysCtlPeripheralSleepDisable(SYSCTL_PERIPH_HIBERNATE);
	    SysCtlPeripheralSleepDisable(SYSCTL_PERIPH_I2C0);
	    SysCtlPeripheralSleepDisable(SYSCTL_PERIPH_I2C1);
	    SysCtlPeripheralSleepDisable(SYSCTL_PERIPH_PWM);
	    SysCtlPeripheralSleepDisable(SYSCTL_PERIPH_QEI0);
	    SysCtlPeripheralSleepDisable(SYSCTL_PERIPH_QEI1);
	    SysCtlPeripheralSleepDisable(SYSCTL_PERIPH_SSI0);
	    SysCtlPeripheralSleepDisable(SYSCTL_PERIPH_SSI1);

	    SysCtlPeripheralSleepDisable(SYSCTL_PERIPH_TIMER0);
	    SysCtlPeripheralSleepDisable(SYSCTL_PERIPH_TIMER1);
	    SysCtlPeripheralSleepDisable(SYSCTL_PERIPH_TIMER2);
	    SysCtlPeripheralSleepDisable(SYSCTL_PERIPH_TIMER3);

	    SysCtlPeripheralSleepDisable(SYSCTL_PERIPH_UART0);
	    SysCtlPeripheralSleepDisable(SYSCTL_PERIPH_UART1);
	    SysCtlPeripheralSleepDisable(SYSCTL_PERIPH_UART2);

	    SysCtlPeripheralSleepDisable(SYSCTL_PERIPH_WDOG);
	    SysCtlPeripheralSleepDisable(SYSCTL_PERIPH_UDMA);
	    SysCtlPeripheralSleepDisable(SYSCTL_PERIPH_USB0);



	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOE);
	GPIOPinTypeGPIOOutput(GPIO_PORTE_BASE, GPIO_PIN_4);
	GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_4, GPIO_PIN_4);


    SysCtlPeripheralEnable(SYSCTL_PERIPH_SSI0);
     SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);

	keyboardInit();

	SysCtlClockSet(SYSCTL_SYSDIV_1 | SYSCTL_USE_OSC | SYSCTL_OSC_INT );

    SysTickPeriodSet(SysCtlClockGet() / 1000);
    IntMasterEnable();
    SysTickIntEnable();
    SysTickEnable();




    SysCtlDelay(SysCtlClockGet() / 20);

	lcdInit();
	adcInit();



	LcdClear();

	appClock();


	for(;;)
		appMain();


}

