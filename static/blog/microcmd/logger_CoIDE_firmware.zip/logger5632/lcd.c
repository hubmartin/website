#include "inc/hw_types.h"
#include "inc/hw_memmap.h"
#include "inc/hw_gpio.h"

#include "driverlib/cpu.h"
#include "driverlib/gpio.h"
#include "driverlib/sysctl.h"
#include "lcd.h"

void LcdWrite(unsigned char dc, unsigned char data)
{
	int i;

	// Select Data or /Cmd
	GPIOPinWrite(SFLASH_CS_BASE, SFLASH_DC, (dc) ? SFLASH_DC : 0);

	// Chip select
	GPIOPinWrite(SFLASH_CS_BASE, SFLASH_CS, 0);


	// Shift data
	for(i = 0; i < 8; i++)
	{
		GPIOPinWrite(SFLASH_CS_BASE, SFLASH_TX, (data & (1<<7)) ? SFLASH_TX : 0);

		// Clock
		GPIOPinWrite(SFLASH_CS_BASE, SFLASH_CLK, SFLASH_CLK);
		GPIOPinWrite(SFLASH_CS_BASE, SFLASH_CLK, 0);

		data = data << 1;
	}

	//shiftOut(PIN_SDIN, PIN_SCLK, MSBFIRST, data);

	// Chip DeSelect
	GPIOPinWrite(SFLASH_CS_BASE, SFLASH_CS, SFLASH_CS);

}

unsigned char swapBits(unsigned char ch)
{
	unsigned char out = 0;

	int i;

	for(i = 0; i < 8; i++)
		out |= ((ch & 1<<i) >> i) << (7-i);

	return out;
}

// gotoXY routine to position cursor
// x - range: 0 to 84
// y - range: 0 to 5

void gotoXY(int x, int y)
{
  LcdWrite( 0, 0x80 | x);  // Column.
  LcdWrite( 0, 0x40 | (5-y));  // Row.

}

void lcdConfigurePins()
{
    GPIOPinTypeGPIOOutput(SFLASH_CS_BASE, SFLASH_DC);
    GPIOPinTypeGPIOOutput(SFLASH_CS_BASE, SFLASH_CS);
    GPIOPinTypeGPIOOutput(SFLASH_CS_BASE, SFLASH_TX);
    GPIOPinTypeGPIOOutput(SFLASH_CS_BASE, SFLASH_CLK);
}

void lcdInit()
{

	// Init CE, CS, CLK, TX
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);
    lcdConfigurePins();

    // Init RESET
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOB);
    GPIOPinTypeGPIOOutput(GPIO_PORTB_BASE, GPIO_PIN_3);

    // Do a reset
    GPIOPinWrite(GPIO_PORTB_BASE, GPIO_PIN_3, 0);
    GPIOPinWrite(GPIO_PORTB_BASE, GPIO_PIN_3, GPIO_PIN_3);

    LcdWrite(LCD_C, 0x20);
    LcdWrite(LCD_C, 0x0C);

}

void LcdCharacter(char character)
{
	int index = 5;
  LcdWrite(LCD_D, 0x00);
  //for (index = 5; index < 5; index--)
  //{
	  while(index--)
	  {
		  LcdWrite(LCD_D, swapBits(ASCII[character - 0x20][index]));
	  }
  LcdWrite(LCD_D, 0x00);
}

void lcdBufferChar(char ch, int x, int y)
{
	int i = 0;
	int j;


	  for(i=0; i < 5; i++)
	  {
		  for(j = 0; j < 8; j++)
			  if(ASCII[ch - 0x20][i] & (1<<j))
				  lcdPutPixel(x+i+1,y+j+1);
	  }

}

void lcdBufferString(char *str, int x, int y)
{
	while(*str != 0)
	{
		lcdBufferChar(*str++, x, y);
		x+= 6;
	}
}

void LcdClear(void)
{
	int index;

	gotoXY(0,0);

  for (index = 0; index < LCD_X * LCD_Y / 8; index++)
  {
    LcdWrite(LCD_D, 0x00);
  }
}



void LcdString(char *characters)
{
  // draw in reverse
  int len = strlen(characters);
  while(len--)
  {
    LcdCharacter(*(characters+len));
  }
}

unsigned char lcdBuffer[504];

void lcdPutPixel(unsigned int x, unsigned int y)
{
	x = 84-x;
	y = 48-y;

	lcdBuffer[x + (y / 8)*LCD_X] |= 1<<(y % 8) ;
}

void lcdClearPixel(unsigned int x, unsigned int y)
{
	x = 84-x;
	y = 48-y;

	  lcdBuffer[x + (y / 8)*LCD_X] &= ~(1<<(y % 8));
}

void lcdDrawBuffer()
{
	int index;

	lcdConfigurePins();

	LcdWrite( 0, 0x80 | 0);  // Column.
	LcdWrite( 0, 0x40 | 0);  // Row.

  for (index = 0; index < LCD_X * (LCD_Y / 8); index++)
  {
    LcdWrite(LCD_D, lcdBuffer[index]);
  }
}

void lcdClearBuffer()
{
int i;

for(i = 0; i < sizeof(lcdBuffer); i++)
		lcdBuffer[i] = 0;

}

