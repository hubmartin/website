signed int sprintf(char *pStr, const char *pFormat, ...);
