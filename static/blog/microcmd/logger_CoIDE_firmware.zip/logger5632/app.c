
#include "inc/hw_types.h"
#include "inc/hw_memmap.h"
#include "inc/hw_gpio.h"
#include "inc/hw_ints.h"
#include "driverlib/cpu.h"
#include "driverlib/gpio.h"
#include "driverlib/debug.h"
#include "driverlib/sysctl.h"
#include "driverlib/adc.h"
#include "driverlib/systick.h"
#include "driverlib/interrupt.h"

#include "driverlib/hibernate.h"

#include "keyboard.h"
#include "menu.h"
#include "lcd.h"
#include "joystick.h"

#include "stdio/printf.h"



#include "fileBrowser/fileBrowser.h"

void
GPIOPortC_IRQHandler(void)
{
	GPIOPinIntClear(GPIO_PORTC_BASE, GPIO_PIN_6);
}


void appShutdown()
{
	  SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);
	    GPIOPinTypeGPIOOutput(SFLASH_CS_BASE, SFLASH_DC);
	    GPIOPinTypeGPIOOutput(SFLASH_CS_BASE, SFLASH_CS);
	    GPIOPinTypeGPIOOutput(SFLASH_CS_BASE, SFLASH_TX);
	    GPIOPinTypeGPIOOutput(SFLASH_CS_BASE, SFLASH_CLK);

	    // Init RESET
	    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOB);


	    GPIOPinWrite(SFLASH_CS_BASE, SFLASH_DC, 0);
	    GPIOPinWrite(SFLASH_CS_BASE, SFLASH_CS, 0);
	    GPIOPinWrite(SFLASH_CS_BASE, SFLASH_TX, 0);
	    GPIOPinWrite(SFLASH_CS_BASE, SFLASH_CLK, 0);
	    GPIOPinWrite(GPIO_PORTB_BASE, GPIO_PIN_3, 0);

	    joystickDisable();
	    SysTickDisable();


	// disable PWR_EN
		SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOE);
		GPIOPinTypeGPIOOutput(GPIO_PORTE_BASE, GPIO_PIN_4);
		GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_4, 0);

		// enable interrupts
	    GPIOIntTypeSet(GPIO_PORTC_BASE, GPIO_PIN_6, GPIO_FALLING_EDGE);
	    GPIOPinIntEnable(GPIO_PORTC_BASE, GPIO_PIN_6);
	    IntEnable(INT_GPIOC);




		SysCtlUSBPLLDisable();


		GPIOPinWrite(GPIO_PORTB_BASE, GPIO_PIN_2, GPIO_PIN_2);

		//SysCtlDeepSleepClockSet(SYSCTL_DSLP_OSC_INT30 | SYSCTL_DSLP_DIV_64);

		    SysCtlPeripheralDeepSleepEnable(SYSCTL_PERIPH_GPIOC);

		// Set the clocking to run directly from the crystal.


		// Deep sleep
		do {
			SysCtlClockSet(SYSCTL_SYSDIV_64 | SYSCTL_USE_OSC |/* SYSCTL_MAIN_OSC_DIS |*/ SYSCTL_OSC_INT30);
			SysCtlDeepSleep();
			SysCtlClockSet(SYSCTL_SYSDIV_1 | SYSCTL_USE_OSC | SYSCTL_OSC_INT);
			//SysCtlDelay(SysCtlClockGet() / 10);
		} while(GPIOPinRead(GPIO_PORTC_BASE, GPIO_PIN_6) != 0);


		SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOB);
		GPIOPinTypeGPIOOutput(GPIO_PORTB_BASE, GPIO_PIN_2);
		GPIOPinWrite(GPIO_PORTB_BASE, GPIO_PIN_2, 0);

		SysTickEnable();
		joystickEnable();

		// Int disable
		GPIOPinIntDisable(GPIO_PORTC_BASE, GPIO_PIN_6);

		// PWR enable
		GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_4, GPIO_PIN_4);

		SysCtlDelay(SysCtlClockGet() / 100);

		lcdInit();
		adcInit();


}



void appJoystick()
{
	int infiniteLoop = 1;

	while(infiniteLoop)
	{

	unsigned long i, x, y;
	char temp[20];

	SysCtlSleep();

	lcdClearBuffer();

	unsigned long ulSeq1DataBuffer[4];

	ADCProcessorTrigger(ADC0_BASE, 1);


	while(!ADCIntStatus(ADC0_BASE, 1, false));

	ADCIntClear(ADC0_BASE, 1);

	ADCSequenceDataGet(ADC0_BASE, 1, ulSeq1DataBuffer);
	x = 1000 - ulSeq1DataBuffer[2];
	y =  ulSeq1DataBuffer[3];

	sprintf(temp, "batt: %u", (unsigned int)ulSeq1DataBuffer[0]);
	lcdBufferString(temp,0,ROW(2));

	sprintf(temp, "temp: %u", (unsigned int)ulSeq1DataBuffer[1]);
	lcdBufferString(temp,0,ROW(3));


		sprintf(temp, "x: %u", (int)x);
		lcdBufferString(temp,0,ROW(0));

		sprintf(temp, "y: %u", (int)y);
		lcdBufferString(temp,0,ROW(1));



		lcdDrawBuffer();
			for( i= 0; i < 10000; i++);



	if(getEvent() == BTN_A)
		return;

	}
}

extern unsigned long msTick;
void delay(unsigned long d);

void appClock()
{
	char temp[10];

	SysCtlPeripheralDeepSleepEnable(SYSCTL_PERIPH_HIBERNATE);
	SysCtlPeripheralSleepEnable(SYSCTL_PERIPH_HIBERNATE);

    SysCtlPeripheralEnable(SYSCTL_PERIPH_HIBERNATE);

    // Put /WAKE pin to HIGH
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOB);
    GPIOPinTypeGPIOOutput(GPIO_PORTB_BASE, GPIO_PIN_7);
    GPIOPinWrite(GPIO_PORTB_BASE, GPIO_PIN_7, GPIO_PIN_7);

    delay(100);

   HibernateEnableExpClk(SysCtlClockGet());
   delay(100);

   HibernateClockSelect(HIBERNATE_CLOCK_SEL_DIV128);

   delay(100);

   HibernateRTCEnable();

   delay(100);

	//SysCtlSleep();
	for(;;)
	{
		SysCtlSleep();
		SysCtlDelay(SysCtlClockGet()/10);

		SysCtlSleep();

		lcdClearBuffer();
		sprintf(temp, "Uptime:%u", (unsigned int)HibernateRTCGet());
		lcdBufferString(temp, 0, 20);
		lcdDrawBuffer();

		SysCtlSleep();

		if(keyboardGet() == BTN_A)
			return;

		SysCtlSleep();
	}

}

void appPaint()
{

	int x = 42, y = 24;


	lcdClearBuffer();

	for(;;)
	{

		if(x < 0)
			x = 0;
		else if(x > 83)
			x = 83;

		if(y < 0)
			y = 0;
		else if(y > 47)
			y = 47;

		lcdPutPixel(x , y );
		lcdDrawBuffer();

		SysCtlSleep();

		switch(keyboardGet())
		{
		case BTN_LEFT:
			x--;
			break;
		case BTN_RIGHT:
			x++;
			break;
		case BTN_UP:
			y--;
			break;
		case BTN_DOWN:
			y++;
			break;

		case BTN_B:
			lcdClearBuffer();
			break;
		case BTN_A:
			return;

		}

	}

}

void appTest()
{
	lcdClearBuffer();
	lcdBufferString("Test app",0,0);
	lcdDrawBuffer();

	while(keyPress == 0)
	{
		SysCtlSleep();
	}
	keyPress = 0;

}

void appMain()
{

	static char *mainMenu[] = { "microCmd", "Joystick", "Malovani", "Clock","Hibernace","Soubory","Vypnout", 0, };
	static void (*funcMenu[])()= {            appJoystick, appPaint,  appClock, appTest, appFileBrowser, appShutdown};


	    int menuSel = - 1;

		 for(;;) {
		 	menuPreselect = menuSel;
			menuSel = showMenu(mainMenu);
			if(menuSel != -1)
				(*funcMenu[(uint8_t)menuSel])();
			else
				break;
		 }



}
