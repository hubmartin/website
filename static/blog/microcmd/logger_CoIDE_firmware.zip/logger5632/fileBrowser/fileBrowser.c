
#include "lcd.h"
#include "keyboard.h"

#include "stdio/printf.h"

#include "fatfs/ff.h"
#include "fileBrowser/fileBrowser.h"

#include "menu.h"

	static DIR g_sDirObject;
	static FILINFO g_sFileInfo;

	static FATFS g_sFatFs;

int fileList()
{


	unsigned long ulTotalSize;
	    unsigned long ulFileCount;
	    unsigned long ulDirCount;
	    FRESULT fresult;
	    FATFS *pFatFs;

#define FILELIST_LEN	150

	    static char fileArray[FILELIST_LEN];
	    int fIndex = 0;
	    int pIndex = 0;
	    static long lPoint[50];

	    char temp[50];
	    char g_cCwdBuf[] = "/";


	    lcdClearBuffer();
	    lcdDrawBuffer();


	    //
	    // Open the current directory for access.
	    //
	    fresult = f_opendir(&g_sDirObject, g_cCwdBuf);

	    //
	    // Check for error and return if there is a problem.
	    //
	    if(fresult != FR_OK)
	    {
	        return(fresult);
	    }

	    ulTotalSize = 0;
	    ulFileCount = 0;
	    ulDirCount = 0;


        strcpy(&fileArray[fIndex], "/");
        lPoint[pIndex] = (unsigned long)&fileArray[fIndex];

        pIndex++;
        fIndex += 1 + 1;





	    //
	    // Enter loop to enumerate through all directory entries.
	    //
	    for(;;)
	    {
	        //
	        // Read an entry from the directory.
	        //
	        fresult = f_readdir(&g_sDirObject, &g_sFileInfo);

	        //
	        // Check for error and return if there is a problem.
	        //
	        if(fresult != FR_OK)
	        {
	            return(fresult);
	        }

	        //
	        // If the file name is blank, then this is the end of the
	        // listing.
	        //
	        if(!g_sFileInfo.fname[0])
	        {
	            break;
	        }

	        //
	        // If the attribue is directory, then increment the directory count.
	        //

	        if(g_sFileInfo.fattrib & AM_DIR)
	        {
	            ulDirCount++;
	        }
	        else
	        {
	            ulFileCount++;
	            ulTotalSize += g_sFileInfo.fsize;
	        }

	        strcpy(&fileArray[fIndex], g_sFileInfo.fname);
	        lPoint[pIndex] = (int)&fileArray[fIndex];

	        pIndex++;
	        fIndex += strlen(g_sFileInfo.fname) + 1;




	        //
	        // Print the entry information on a single line with formatting
	        // to show the attributes, date, time, size, and name.
	        //
	        /*
	        UARTprintf("%c%c%c%c%c %u/%02u/%02u %02u:%02u %9u  %s\n",
	                    (g_sFileInfo.fattrib & AM_DIR) ? 'D' : '-',
	                    (g_sFileInfo.fattrib & AM_RDO) ? 'R' : '-',
	                    (g_sFileInfo.fattrib & AM_HID) ? 'H' : '-',
	                    (g_sFileInfo.fattrib & AM_SYS) ? 'S' : '-',
	                    (g_sFileInfo.fattrib & AM_ARC) ? 'A' : '-',
	                    (g_sFileInfo.fdate >> 9) + 1980,
	                    (g_sFileInfo.fdate >> 5) & 15,
	                     g_sFileInfo.fdate & 31,
	                    (g_sFileInfo.ftime >> 11),
	                    (g_sFileInfo.ftime >> 5) & 63,
	                     g_sFileInfo.fsize,
	                     g_sFileInfo.fname);*/
	    }   // endfor


	    //l[lPoint] = 0;
	    //l[lPoint] = 0;

	    showMenu((char**)&lPoint);
	    return 0;

	    //
	    // Get the free space.
	    //
	    fresult = f_getfree("/", &ulTotalSize, &pFatFs);

	    //
	    // Check for error and return if there is a problem.
	    //
	    if(fresult != FR_OK)
	    {
	        return(fresult);
	    }



	    sprintf(temp,"Souboru:%d", (int)ulFileCount);
	    lcdBufferString(temp, COL(0), ROW(1));

		sprintf(temp,"Slozek:%d", (int)ulDirCount);
		lcdBufferString(temp, COL(0), ROW(2));

		sprintf(temp,"Free:%d", (int)ulTotalSize);
		lcdBufferString(temp, COL(0), ROW(3));

		lcdDrawBuffer();

		while(getEvent() != BTN_A);

	    //
	    // Display the amount of free space that was calculated.
	    //
	    //UARTprintf(", %10uK bytes free\n", ulTotalSize * pFatFs->sects_clust / 2);

	    //
	    // Made it to here, return with no errors.
	    //
	    return(0);

}


void appFileBrowser()
{
FRESULT fresult;
    fresult = f_mount(0, &g_sFatFs);
    if(fresult != FR_OK)
    {
       return;
    }

	fileList();

	/*
	static FATFS g_sFatFs;

	static FIL g_sFileObject;

	//int nStatus;
	    FRESULT fresult;
    static char g_cTmpBuf[150];
    unsigned short usBytesRead;


    lcdClearBuffer();

    fresult = f_mount(0, &g_sFatFs);
    if(fresult != FR_OK)
    {
       return;
    }


    //
        // Open the file for reading.
        //
        fresult = f_open(&g_sFileObject, "hello.txt", FA_READ);

        //
        // If there was some problem opening the file, then return
        // an error.
        //
        if(fresult != FR_OK)
        {
            return;
        }

        //
        // Enter a loop to repeatedly read data from the file and display it,
        // until the end of the file is reached.
        //
        do
        {
            //
            // Read a block of data from the file.  Read as much as can fit
            // in the temporary buffer, including a space for the trailing null.
            //
            fresult = f_read(&g_sFileObject, g_cTmpBuf, sizeof(g_cTmpBuf) - 1,
                             &usBytesRead);

            //
            // If there was an error reading, then print a newline and
            // return the error to the user.
            //
            if(fresult != FR_OK)
            {
                //UARTprintf("\n");
                return;
            }

            //
            // Null terminate the last block that was read to make it a
            // null terminated string that can be used with printf.
            //
            g_cTmpBuf[usBytesRead] = 0;

            //
            // Print the last chunk of the file that was received.
            //
            //lcdInit();



            lcdBufferString(g_cTmpBuf, 0 , 0);


        //
        // Continue reading until less than the full number of bytes are
        // read.  That means the end of the buffer was reached.
        //
        }
        while(usBytesRead == sizeof(g_cTmpBuf) - 1);

        lcdDrawBuffer();

        while(getEvent() != BTN_A);
*/
}
