/* ========================================================================== */
/*                                                                            */
/*   main.c                                                                   */
/*   (c) 2011 Martin Hubacek - martinhubacek.cz                               */
/*                                                                            */
/*   Library for Wii Nunchuk controller                                       */
/*                                                                            */
/* ========================================================================== */

// Evalbot nunchuk control
// Martin Hubacek
// www.martinhubacek.cz

// ****** OLED & MOTOR libraries by senatorpenguin ******


#define TARGET_IS_TEMPEST_RB1

#include "inc/lm3s9b92.h"
#include "inc/hw_types.h"
#include "driverlib/gpio.h"
#include "driverlib/sysctl.h"
#include "inc/hw_memmap.h"

#include "driverlib/i2c.h"
#include "inc/hw_i2c.h"

#include "driverlib/rom.h"


#include "driverlib/uart.h"

#define LBUMPER_PRESSED() (ROM_GPIOPinRead(GPIO_PORTE_BASE, GPIO_PIN_1) == 0)
#define RBUMPER_PRESSED() (ROM_GPIOPinRead(GPIO_PORTE_BASE, GPIO_PIN_0) == 0)
#define SW1_PRESSED() (ROM_GPIOPinRead(GPIO_PORTD_BASE, GPIO_PIN_6) == 0)
#define SW2_PRESSED() (ROM_GPIOPinRead(GPIO_PORTD_BASE, GPIO_PIN_7) == 0)



#include "oled.h"
#include "motor.h"
#include "nunchuk.h"

// System timer interrupt
// look in gcc_Startup.c a search for SysTickHandler to
// understand how work with interrupts
void SysTickHandler()
{
  // Invert pin4
  GPIO_PORTF_DATA_R ^= 0x01 << 4;

	nunchuckReadData();
 
}


void UARTInit()
{
     //
    // Enable the peripherals used by this example.
    //
    ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);
    ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);
    
    //
    // Set GPIO A0 and A1 as UART pins.
    //
    GPIOPinConfigure(GPIO_PA0_U0RX);
    GPIOPinConfigure(GPIO_PA1_U0TX);
    ROM_GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);

    //
    // Configure the UART for 115,200, 8-N-1 operation.
    //
    ROM_UARTConfigSetExpClk(UART0_BASE, ROM_SysCtlClockGet(), 115200,
                            (UART_CONFIG_WLEN_8 | UART_CONFIG_STOP_ONE |
                             UART_CONFIG_PAR_NONE));
                             
    UARTStdioInit(0);

}

void main(void)
{
  unsigned long ulSlaveReceive = 0;

  // enable +5V USB
  //SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);
  //GPIOPinTypeGPIOOutput(GPIO_PORTA_BASE, GPIO_PIN_6);
  //GPIO_PORTA_DATA_R |= 1 << 6;
   ROM_SysCtlClockSet(SYSCTL_SYSDIV_4 | SYSCTL_USE_PLL | SYSCTL_OSC_MAIN | SYSCTL_XTAL_16MHZ);
   
   // Setup clock for 20Mhz
   // SysCtlClockSet(SYSCTL_SYSDIV_10 | SYSCTL_USE_PLL | SYSCTL_OSC_MAIN | SYSCTL_XTAL_16MHZ);


  // Enable systick - system timer
  ROM_SysTickPeriodSet(SysCtlClockGet() / 10);
  ROM_SysTickEnable();
  

  // LED is on pin PF4
	ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);
	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTF_BASE, GPIO_PIN_4 | GPIO_PIN_5);

  UARTInit();
  
  ROM_UARTCharPutNonBlocking(UART0_BASE, 'H');
  ROM_UARTCharPutNonBlocking(UART0_BASE, 'i');
  ROM_UARTCharPutNonBlocking(UART0_BASE, '\n');

  init_motorPWM();

  init_display();
	dispString("I2C Nunchuk Demo",0,0);
	dispString("martinhubacek.cz",0,1);
	
	
	nunchukInit();
	
	
	ROM_SysTickIntEnable();
	

		while(1)  {
		
			
	if( btnC )
	{	
		if(joyY > 160)
		{
			setMotor(MOTOR_R, MOTOR_DIR_F, (0x40/(216 - 160)) * (joyY-160));
			setMotor(MOTOR_L, MOTOR_DIR_F, (0x40/(216 - 160)) * (joyY-160));
		}
		else if( joyY <= 90)
		{
		  setMotor(MOTOR_R, MOTOR_DIR_B, 0x40);
			setMotor(MOTOR_L, MOTOR_DIR_B, 0x40);
		}
		else if(joyX > 170)
		{
			setMotor(MOTOR_R, MOTOR_DIR_B, 0x40);
			setMotor(MOTOR_L, MOTOR_DIR_F, 0x40);
		}
		else if( joyX <= 90)
		{
		  setMotor(MOTOR_R, MOTOR_DIR_F, 0x40);
			setMotor(MOTOR_L, MOTOR_DIR_B, 0x40);
		}
		else
		{
			setMotor(MOTOR_R, MOTOR_DIR_F, 0x00);
			setMotor(MOTOR_L, MOTOR_DIR_F, 0x00);
		}
	
	} else if ( btnZ )
	{
	  
	  if(accY > 600)
		{
			setMotor(MOTOR_R, MOTOR_DIR_F, 0x40); //(0x40/(750 - 600)) * (accY-600));
			setMotor(MOTOR_L, MOTOR_DIR_F, 0x40); //(0x40/(750 - 600)) * (accY-600));
		}
		else if( accY <= 400)
		{
		  setMotor(MOTOR_R, MOTOR_DIR_B, 0x40);
			setMotor(MOTOR_L, MOTOR_DIR_B, 0x40);
		}
		else if(accX > 700)
		{
			setMotor(MOTOR_R, MOTOR_DIR_B, 0x40);
			setMotor(MOTOR_L, MOTOR_DIR_F, 0x40);
		}
		else if( accX <= 400)
		{
		  setMotor(MOTOR_R, MOTOR_DIR_F, 0x40);
			setMotor(MOTOR_L, MOTOR_DIR_B, 0x40);
		}
		else
		{
			setMotor(MOTOR_R, MOTOR_DIR_F, 0x00);
			setMotor(MOTOR_L, MOTOR_DIR_F, 0x00);
		}
	
	} else {
	   setMotor(MOTOR_R, MOTOR_DIR_F, 0x00);
		setMotor(MOTOR_L, MOTOR_DIR_F, 0x00);
	}  

		}						

  
}


