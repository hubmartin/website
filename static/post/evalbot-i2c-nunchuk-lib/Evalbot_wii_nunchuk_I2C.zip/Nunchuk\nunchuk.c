/* ========================================================================== */
/*                                                                            */
/*   nunchuk.c                                                                */
/*   (c) 2011 Martin Hubacek - martinhubacek.cz                               */
/*                                                                            */
/*   Library for Wii Nunchuk controller                                       */
/*                                                                            */
/* ========================================================================== */
#include "nunchuk.h"
#include "I2Clib.h"

void nunchukInit()
{
	char handShake[] = {0x40, 0x00};

	I2CInit(GPIO_PB2_I2C0SCL);
	I2CWriteData(I2C0_MASTER_BASE, 0x52, handShake, sizeof(handShake)); 

}

void nunchuckRecieveRequest()
{
	char readValues[] = {0x00};
	I2CWriteData(I2C0_MASTER_BASE, 0x52, readValues, sizeof(readValues)); 
}


void nunchuckReadData()
{

	char data[6];
	int i;

	// Read 6 bytes
	I2CReadData(I2C0_MASTER_BASE, 0x52, data , 6);
	
	// Necessary for original Nunchuk
	for(i=0; i < 6; i++)
		data[i] = (data[i] ^ 0x17) + 0x17;
	
	
	// Decode read bytes
	joyX = data[0];
	joyY = data[1];
	
	accX = data[2] << 2 | ((data[5] >> 2) & 0x03); 
	accY = data[3] << 2 | ((data[5] >> 4) & 0x03) ;
	accZ = data[4] << 2 | ((data[5] >> 6) & 0x03) ;
	
	btnZ = (data[5] & 0x01) == 0;
	btnC = ((data[5] >> 1) & 0x01) == 0;
	

	// Debug values
	UARTprintf("%u, %u, %u, %u, %u, %c, %c\n", joyX, joyY, accX, accY, accZ, btnC ? '1' : '0',  btnZ ? '1' : '0' );
	
	// Send request for new values for future reading
  nunchuckRecieveRequest();

}