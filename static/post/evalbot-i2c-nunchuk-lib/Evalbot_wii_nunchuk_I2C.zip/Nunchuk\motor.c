#define TARGET_IS_TEMPEST_RB1

#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "driverlib/debug.h"
#include "driverlib/pwm.h"
#include "driverlib/rom.h"
#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"
#include "motor.h"



//	PD0/PWM0 = PWM_R
//	PD1/PWM1 = PHASE_R
//	PD2 = SLOW_DECAY
//	PD5 = 12V supply enable
//	PH0/PWM2 = PWM_L
//	PH1/PWM3 = PHASE_L

//The period of the PWM counter
//In up down mode, this is actually 1/2 the period
unsigned long pwm_period;

//Set the power and direction of one of the motors.
void setMotor(unsigned char motor, unsigned char dir, unsigned char power) {
	//Find the width of the pulse from a power byte
	unsigned long pulseWidth = (2 * pwm_period * power) >> 8;
	
	//Set the phase pin according to motor direction,
	//Set the PWM pulse width according to motor power
	if (motor == MOTOR_R) {
		ROM_PWMPulseWidthSet(PWM_BASE, PWM_GEN_0, pulseWidth);
		ROM_GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_1, (dir==MOTOR_DIR_F) ? GPIO_PIN_1 : 0);
	} else if (motor == MOTOR_L) {
		ROM_PWMPulseWidthSet(PWM_BASE, PWM_GEN_1, pulseWidth);
		ROM_GPIOPinWrite(GPIO_PORTH_BASE, GPIO_PIN_1, (dir==MOTOR_DIR_B) ? GPIO_PIN_1 : 0);
	}
}

//Initialize the peripherals necessary for using the motor drivers
void init_motorPWM() {

	//Enable the peripherals
	ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_PWM);
	ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOD);
	ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOH);
	
	//Configure PWM pins
	GPIOPinConfigure(GPIO_PD0_PWM0);
	GPIOPinConfigure(GPIO_PH0_PWM2);
	ROM_GPIOPinTypePWM(GPIO_PORTD_BASE, GPIO_PIN_0);
	ROM_GPIOPinTypePWM(GPIO_PORTH_BASE, GPIO_PIN_0);
	
	//Confiugre phase pins
	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTD_BASE, GPIO_PIN_1);
	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTH_BASE, GPIO_PIN_1);
	
	//Enable MFAULT sensing with pullup
	ROM_GPIOPinTypeGPIOInput(GPIO_PORTD_BASE, GPIO_PIN_3);
	ROM_GPIOPadConfigSet(GPIO_PORTD_BASE, GPIO_PIN_3, GPIO_STRENGTH_2MA, GPIO_PIN_TYPE_STD_WPU);
    
    //Enable slow decay mode
    GPIOPinTypeGPIOOutput(GPIO_PORTD_BASE, GPIO_PIN_2);
    GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_2, GPIO_PIN_2);
	
	//Enable the 12V motor supply
	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTD_BASE, GPIO_PIN_5);
	ROM_GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_5, GPIO_PIN_5);
	
	//Configure PWM generators at 440 Hz
	pwm_period = ROM_SysCtlClockGet() / (440 * 2);
	ROM_PWMGenConfigure(PWM_BASE, PWM_GEN_0, PWM_GEN_MODE_UP_DOWN | PWM_GEN_MODE_NO_SYNC);
	ROM_PWMGenConfigure(PWM_BASE, PWM_GEN_1, PWM_GEN_MODE_UP_DOWN | PWM_GEN_MODE_NO_SYNC);
	ROM_PWMGenPeriodSet(PWM_BASE, PWM_GEN_0, pwm_period);
	ROM_PWMGenPeriodSet(PWM_BASE, PWM_GEN_1, pwm_period);
	
	//Zero motors
	ROM_PWMPulseWidthSet(PWM_BASE, PWM_GEN_0, 0);
	ROM_PWMPulseWidthSet(PWM_BASE, PWM_GEN_1, 0);
	
	//Turn on PWM generators and outputs
	ROM_PWMOutputState(PWM_BASE, PWM_OUT_0_BIT | PWM_OUT_2_BIT, true);
	ROM_PWMGenEnable(PWM_BASE, PWM_GEN_0);
	ROM_PWMGenEnable(PWM_BASE, PWM_GEN_1);
	
}