
#define TARGET_IS_TEMPEST_RB1

#include "inc/lm3s9b92.h"
#include "inc/hw_types.h"
#include "driverlib/gpio.h"
#include "driverlib/sysctl.h"
#include "inc/hw_memmap.h"

#include "driverlib/i2c.h"
#include "inc/hw_i2c.h"

#include "driverlib/rom.h"


#define LBUMPER_PRESSED() (ROM_GPIOPinRead(GPIO_PORTE_BASE, GPIO_PIN_1) == 0)
#define RBUMPER_PRESSED() (ROM_GPIOPinRead(GPIO_PORTE_BASE, GPIO_PIN_0) == 0)
#define SW1_PRESSED() (ROM_GPIOPinRead(GPIO_PORTD_BASE, GPIO_PIN_6) == 0)
#define SW2_PRESSED() (ROM_GPIOPinRead(GPIO_PORTD_BASE, GPIO_PIN_7) == 0)

// Evalbot nunchuk control
// Martin Hubacek
// electronics.martinhubacek.cz

// peripheral libraries by senatorpenguin

#include "oled.h"
#include "motor.h"
#include "nunchuk.h"

// System timer interrupt
// look in gcc_Startup.c a search for SysTickHandler to
// understand how work with interrupts
void SysTickHandler()
{
  // Invert pin4
  //GPIO_PORTF_DATA_R ^= 0x01 << 4;
  //nunchukWriteByte(0xAA); 
}


void main(void)
{
          unsigned long ulSlaveReceive = 0;

  // enable +5V USB
  //SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);
  //GPIOPinTypeGPIOOutput(GPIO_PORTA_BASE, GPIO_PIN_6);
  //GPIO_PORTA_DATA_R |= 1 << 6;
   //ROM_SysCtlClockSet(SYSCTL_SYSDIV_4 | SYSCTL_USE_PLL | SYSCTL_OSC_MAIN | SYSCTL_XTAL_16MHZ);
   
   // Setup clock for 20Mhz
    SysCtlClockSet(SYSCTL_SYSDIV_10 | SYSCTL_USE_PLL | SYSCTL_OSC_MAIN | SYSCTL_XTAL_16MHZ);

  // LED is on pin PF4
	ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);
	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTF_BASE, GPIO_PIN_4 | GPIO_PIN_5);
	  /*
	// Bumper buttons
	ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOE);
	ROM_GPIOPinTypeGPIOInput(GPIO_PORTE_BASE, GPIO_PIN_0 | GPIO_PIN_1);
	ROM_GPIOPadConfigSet(GPIO_PORTE_BASE, GPIO_PIN_0 | GPIO_PIN_1, GPIO_STRENGTH_2MA, GPIO_PIN_TYPE_STD_WPU);
	
	// User buttons
	ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOD);
	ROM_GPIOPinTypeGPIOInput(GPIO_PORTD_BASE, GPIO_PIN_6 | GPIO_PIN_7);
	ROM_GPIOPadConfigSet(GPIO_PORTD_BASE, GPIO_PIN_6 | GPIO_PIN_7, GPIO_STRENGTH_2MA, GPIO_PIN_TYPE_STD_WPU);
	
	// Enable systick - system timer
  ROM_SysTickPeriodSet(SysCtlClockGet() / 1);
  ROM_SysTickEnable();
  ROM_SysTickIntEnable();
	       */
  //GPIO_PORTF_DATA_R |= 0x01 << 4;
  
  //init_motorPWM();

	//init_display();
	//dispString("Ahoj            ",0,0);
	//dispString("firmware update ",0,1);
	
	
	
	
	

//
// Turn on I2S0 and reset to a known state
//
SysCtlPeripheralEnable(SYSCTL_PERIPH_I2C0);
SysCtlPeripheralReset(SYSCTL_PERIPH_I2C0);

//
// Enable loopback
//
//HWREG(I2C0_MASTER_BASE + I2C_O_MCR) = 0x01;

//
// Configure the PortB pins for I2C0
//
SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOB);
GPIOPinTypeI2C(GPIO_PORTB_BASE, GPIO_PIN_2 | GPIO_PIN_3);

GPIOPinConfigure(GPIO_PB2_I2C0SCL);
    GPIOPinConfigure(GPIO_PB3_I2C0SDA);

//
// Enable and Initalize MASTER/SLAVE
//
I2CMasterEnable(I2C0_MASTER_BASE);
I2CMasterInitExpClk(I2C0_MASTER_BASE, SysCtlClockGet(), false);
I2CSlaveEnable(I2C0_SLAVE_BASE);
I2CSlaveInit(I2C0_SLAVE_BASE, 0x3C);

//
// Set the slave address, and set the Master to Transmit mode
//
I2CMasterSlaveAddrSet(I2C0_MASTER_BASE, 0x3C, false);

//
// Place the character to be sent in the data register
//
I2CMasterDataPut(I2C0_MASTER_BASE, 'J');

//
// Initiate the send of the character from Master to Slave
//
I2CMasterControl(I2C0_MASTER_BASE, I2C_MASTER_CMD_SINGLE_SEND);
/*
//
// Wait until the slave has received the character.
//
while(!(I2CSlaveStatus(I2C0_SLAVE_BASE) & I2C_SCSR_RREQ)){}

//
// Read the character from the slave.
//
ulSlaveReceive = I2CSlaveDataGet(I2C0_SLAVE_BASE);

//
// Delay until transmission completes
//
while(I2CMasterBusy(I2C0_MASTER_BASE))
{
}

if(ulSlaveReceive == 'J')
{
// Success 
GPIO_PORTF_DATA_R |= 1 << 4;
while(1){}
}
else
{
// Failure 
while(1){}
}
*/	
	    
	
	
	          /*
	
    //SysCtlPeripheralEnable(SYSCTL_PERIPH_I2C1);
    //SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOJ);

    // Turn on I2C1 and reset to a known state
    SysCtlPeripheralEnable(SYSCTL_PERIPH_I2C1);
    SysCtlPeripheralReset(SYSCTL_PERIPH_I2C1);

    // Configure the PortB pins for I2C1
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOJ);
    
    
        // I2C1 is not configured for I2C as default 
    // -> GPIOPinConfigure() is needed
    GPIOPinConfigure(GPIO_PJ0_I2C1SCL);
    GPIOPinConfigure(GPIO_PJ1_I2C1SDA);

    



    // Set GPIO Pins for Open-Drain operation
    GPIOPadConfigSet(GPIO_PORTB_BASE, GPIO_PIN_2, GPIO_STRENGTH_2MA, GPIO_PIN_TYPE_OD);
    GPIOPadConfigSet(GPIO_PORTB_BASE, GPIO_PIN_3, GPIO_STRENGTH_2MA, GPIO_PIN_TYPE_OD);

    // Give control to the I2C Module
    GPIODirModeSet(GPIO_PORTB_BASE, GPIO_PIN_2, GPIO_DIR_MODE_HW);
    GPIODirModeSet(GPIO_PORTB_BASE, GPIO_PIN_3, GPIO_DIR_MODE_HW);

    // Enable and Initialize Master module and Master Clock using 100kbps
    I2CMasterInitExpClk(I2C1_MASTER_BASE, SysCtlClockGet(), 0);
             */
    
                /*
    SysCtlDelay(1800);
	  //ROM_GPIOPinTypeGPIOOutput(GPIO_PORTJ_BASE, GPIO_PIN_0 | GPIO_PIN_1);
	  //GPIO_PORTJ_DATA_R |= 0x03;

    GPIOPinConfigure(GPIO_PJ0_I2C1SCL);
	  GPIOPinConfigure(GPIO_PJ1_I2C1SDA);
    
    GPIOPinTypeI2C(GPIO_PORTJ_BASE, GPIO_PIN_0 | GPIO_PIN_1);
    SysCtlDelay(1800);
    
    SysCtlPeripheralEnable(SYSCTL_PERIPH_I2C1);
    
    SysCtlDelay(1800);
    //I2CMasterEnable(I2C1_MASTER_BASE);
    
	
		I2CMasterInitExpClk(I2C1_MASTER_BASE, SysCtlClockGet(), true);
		           */
		           
		           
		
		
		while(1)
			  nunchukWriteByte(0xaa); 
								

  
}


