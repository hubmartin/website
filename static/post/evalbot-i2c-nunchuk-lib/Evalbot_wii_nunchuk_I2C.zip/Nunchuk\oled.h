
#define TARGET_IS_TEMPEST_RB1

void init_display();
void dispWriteFirst(const char);
void dispWriteArray(const char*, unsigned long);
void dispWriteByte(const char); 
void dispWriteFinal(const char);
void dispMoveCursor(unsigned int, unsigned int, char);
void dispString(const char*, unsigned int, unsigned int);
void dispImage(const char*, unsigned int, unsigned int, unsigned int, unsigned int);
void dispClear();
void dispOn();
void dispOff();