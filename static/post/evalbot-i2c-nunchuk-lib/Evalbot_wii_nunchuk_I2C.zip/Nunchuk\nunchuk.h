/* ========================================================================== */
/*                                                                            */
/*   nunchuk.h                                                                */
/*   (c) 2011 Martin Hubacek - martinhubacek.cz                               */
/*                                                                            */
/*   Library for Wii Nunchuk controller                                       */
/*                                                                            */
/* ========================================================================== */

#ifndef _nunchuk_h_
#define _nunchuk_h_

#define TARGET_IS_TEMPEST_RB1

#include "inc/lm3s9b92.h"
#include "inc/hw_types.h"
#include "driverlib/gpio.h"
#include "driverlib/sysctl.h"
#include "inc/hw_memmap.h"
#include "inc/hw_i2c.h"
#include "driverlib/i2c.h"
#include "driverlib/rom.h"
#include "driverlib/uart.h"

void nunchuckInit();
void nunchukReadData();

int joyX, joyY;
int accX, accY, accZ;
int btnC, btnZ;


#endif // _nunchuk_h_