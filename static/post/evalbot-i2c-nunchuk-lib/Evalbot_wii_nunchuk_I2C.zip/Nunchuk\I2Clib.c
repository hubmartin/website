/* ========================================================================== */
/*                                                                            */
/*   I2Clib.c                                                                 */
/*   (c) 2011 Martin Hubacek - martinhubacek.cz                               */
/*                                                                            */
/*   Simple generic I2C library for EvalBot                                   */
/*                                                                            */
/* ========================================================================== */

#include "I2Clib.h"

// Clock signal pin is vor versatility because you can use
// more than one I2C module and every module can be multiplexed
// between pins.  
void I2CInit(int clockSignalPin)
{

	// Initialize I2C module #0 on pins PB2 & PB3
	if(clockSignalPin == GPIO_PB2_I2C0SCL)
	{
		// Turn on I2S0 and reset to a known state
		SysCtlPeripheralEnable(SYSCTL_PERIPH_I2C0);
		SysCtlPeripheralReset(SYSCTL_PERIPH_I2C0);
		
		// Configure the PortB pins for I2C0
		SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOB);
		GPIOPinTypeI2C(GPIO_PORTB_BASE, GPIO_PIN_2 | GPIO_PIN_3);
		
		// Set correct multiplexed pin 
		GPIOPinConfigure(GPIO_PB2_I2C0SCL);
		GPIOPinConfigure(GPIO_PB3_I2C0SDA);
		
		// Set GPIO Pins for Open-Drain operation
		GPIOPadConfigSet(GPIO_PORTB_BASE, GPIO_PIN_2, GPIO_STRENGTH_2MA, GPIO_PIN_TYPE_OD);
		GPIOPadConfigSet(GPIO_PORTB_BASE, GPIO_PIN_3, GPIO_STRENGTH_2MA, GPIO_PIN_TYPE_OD);
		
		// Give control to the I2C Module
		GPIODirModeSet(GPIO_PORTB_BASE, GPIO_PIN_2, GPIO_DIR_MODE_HW);
		GPIODirModeSet(GPIO_PORTB_BASE, GPIO_PIN_3, GPIO_DIR_MODE_HW);
		
		// Enable and Initalize MASTER/SLAVE
		I2CMasterEnable(I2C0_MASTER_BASE);
		I2CMasterInitExpClk(I2C0_MASTER_BASE, SysCtlClockGet(), false);
	} 
		  
}

void I2CWriteData(int peripheral, int address, char* data, int numberOfBytes)
{
	int i;
	int controlWord;
	
	// Wait for previous transfer
  while(I2CMasterBusy(peripheral));
  
  // Load address and set that we want read (false)
  ROM_I2CMasterSlaveAddrSet(peripheral, address, false);
  
	// We want burst transfer (more than 1 byte)
  controlWord = I2C_MASTER_CMD_BURST_SEND_START;
  
  
  for( i = 0; i < numberOfBytes; i++)
  {
  	// The second byte has to be send with CONTINUE control word
  	if(i == 1)
			controlWord = I2C_MASTER_CMD_BURST_SEND_CONT;
		// The last byte has to be send with FINISH control word
		if(i == numberOfBytes - 1)
			controlWord = I2C_MASTER_CMD_BURST_SEND_FINISH;
		// If we have only one byte to send, it is not BURST send but SINGLE
		if(numberOfBytes == 1)
			controlWord = I2C_MASTER_CMD_SINGLE_SEND;
		
		// Set byte to send	
		I2CMasterDataPut(peripheral, data[i]);
		// Send byte
		I2CMasterControl(peripheral, controlWord);
	
		// Wait to send the byte 
		while(I2CMasterBusy(peripheral)); 
  
  }
	
}


int I2CReadData(int peripheral, int address, char* data, int numberOfBytes)
{

	int i;
  int controlWord;
  
  // Wait for previous transfer
  while(I2CMasterBusy(peripheral));
  
  // Load address and set that we want write (true)
  I2CMasterSlaveAddrSet(peripheral, address, true);

  // We want burst transfer (more than 1 byte)
	controlWord = I2C_MASTER_CMD_BURST_RECEIVE_START;

	for(i = 0; i < numberOfBytes; i++)
	{
		// The second byte has to be receive with CONTINUE control word
		if(i == 1)
			controlWord = I2C_MASTER_CMD_BURST_RECEIVE_CONT;
		// The last byte has to be receive with FINISH control word
		if(i == numberOfBytes - 1)
			controlWord = I2C_MASTER_CMD_BURST_RECEIVE_FINISH;
		// If we have only one byte to receive, it is not BURST send but SINGLE
		if(numberOfBytes == 1)
			controlWord = I2C_MASTER_CMD_SINGLE_RECEIVE; 
	
		// Read a byte
		I2CMasterControl(peripheral, controlWord);
		// Wait to finish reading
	  while(I2CMasterBusy(peripheral));
	  
		// Check for errors             
    if (I2CMasterErr(peripheral) != I2C_MASTER_ERR_NONE)
			return -1;
		
		// Move byte from register	                    
    data[i] = I2CMasterDataGet(peripheral);      
	}
	
	// send number of received bytes
	return i;

}