#define MOTOR_R			0
#define MOTOR_L			1
#define MOTOR_DIR_F		1
#define MOTOR_DIR_B		0



void setMotor(unsigned char motor, unsigned char dir, unsigned char power);
void init_motorPWM();