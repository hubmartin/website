/* ========================================================================== */
/*                                                                            */
/*   I2Clib.h                                                                 */
/*   (c) 2011 Martin Hubacek - martinhubacek.cz                               */
/*                                                                            */
/*   Simple generic I2C library for EvalBot                                   */
/*                                                                            */
/* ========================================================================== */


#ifndef _I2Clib_h_
#define _I2Clib_h_

#define TARGET_IS_TEMPEST_RB1

#include "inc/lm3s9b92.h"
#include "inc/hw_types.h"
#include "driverlib/gpio.h"
#include "driverlib/sysctl.h"
#include "inc/hw_memmap.h"

#include "inc/hw_i2c.h"
#include "driverlib/i2c.h"

#include "driverlib/rom.h"

#include "driverlib/uart.h"

void I2CInit(int clockSignalPin);
void I2CWriteData(int peripheral, int address, char* data, int numberOfBytes);
int I2CReadData(int peripheral, int address, char* data, int numberOfBytes);


#endif // _I2Clib_h_